﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace Prototype
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        SQLiteConnection m_dbConnection;

        public Form1()
        {
            InitializeComponent();

            // create and connect to the database 
            SQLiteConnection.CreateFile("MyDatabase.sqlite");
            m_dbConnection = new SQLiteConnection("Data Source=MyDatabase.sqlite;Version=3;");
            m_dbConnection.Open();

            // create a table
            string sql = "create table student (first_name varchar(20), last_name varchar(20), id int)";
            SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
            command.ExecuteNonQuery();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string first_name = this.textBox1.Text;
            string last_name = this.textBox2.Text;
            string id = this.textBox3.Text;

            StreamWriter writer = new StreamWriter("C:\\Users\\aburke3\\Desktop\\outFile.txt");

            // insert a row into the table 
            string sql = "insert into student (first_name, last_name, id) ";

            sql += "values ('" + first_name + "', " + "'" + last_name + "', " + id + ")";
            SQLiteCommand command = new SQLiteCommand(sql, m_dbConnection);
            command.ExecuteNonQuery();

            // query the table and output the results to a file
            sql = "select * from student";

            command = new SQLiteCommand(sql, m_dbConnection);
            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
                writer.WriteLine("First Name: " + reader["first_name"] + "\tLast Name: " + reader["last_name"] + "\tStudent ID: " + reader["id"]);
            writer.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }  
    }
}
