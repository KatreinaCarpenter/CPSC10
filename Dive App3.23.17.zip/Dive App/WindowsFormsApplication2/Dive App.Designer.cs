﻿namespace WindowsFormsApplication2
{
    partial class Start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Start));
            this.toolbar = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.startButton = new System.Windows.Forms.Button();
            this.diverLogButton = new System.Windows.Forms.Button();
            this.reportButton = new System.Windows.Forms.Button();
            this.preDiveButton = new System.Windows.Forms.Button();
            this.activeDiveButton = new System.Windows.Forms.Button();
            this.postDiveButton = new System.Windows.Forms.Button();
            this.startPanel = new System.Windows.Forms.Panel();
            this.startPanelForm = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.startLabel = new System.Windows.Forms.Label();
            this.diverLogPanel = new System.Windows.Forms.Panel();
            this.diverLogFormPanel = new System.Windows.Forms.Panel();
            this.removeDiver = new System.Windows.Forms.Button();
            this.diverList = new System.Windows.Forms.TextBox();
            this.diverName = new System.Windows.Forms.TextBox();
            this.addDiver = new System.Windows.Forms.Button();
            this.diverLogLabel = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.reportPanel = new System.Windows.Forms.Panel();
            this.reportFormPanel = new System.Windows.Forms.Panel();
            this.reportLabel = new System.Windows.Forms.Label();
            this.preDivePanel = new System.Windows.Forms.Panel();
            this.preDiveFormPanel = new System.Windows.Forms.Panel();
            this.preDiveTable = new System.Windows.Forms.TableLayoutPanel();
            this.preReportLabel = new System.Windows.Forms.Label();
            this.preDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.preReportNum = new System.Windows.Forms.TextBox();
            this.preStateMissionLabel = new System.Windows.Forms.Label();
            this.preStateMissionNum = new System.Windows.Forms.TextBox();
            this.preOpCompletionLabel = new System.Windows.Forms.Label();
            this.preCaseInvestigatorLabel = new System.Windows.Forms.Label();
            this.preOpPlanCompletedBy = new System.Windows.Forms.TextBox();
            this.preCaseInvestigator = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.preBriefingLocation = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.preSituation = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.preTypeOfOperation = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.preAnticipatedDate = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.preAnticipatedTime = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.preLocationAndDescription = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.preSiteSurvey = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.preWitnessName = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.preWitnessPhone = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.preWitnessAddress = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.preVehicleMake = new System.Windows.Forms.TextBox();
            this.preVehicleModel = new System.Windows.Forms.TextBox();
            this.preVehicleYear = new System.Windows.Forms.TextBox();
            this.preVehicleColor = new System.Windows.Forms.TextBox();
            this.preVehiclePlate = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.preSceneAssessment = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.preWaterFlow = new System.Windows.Forms.TextBox();
            this.preWaterDepth = new System.Windows.Forms.TextBox();
            this.preWaterTemp = new System.Windows.Forms.TextBox();
            this.preWaterVisibility = new System.Windows.Forms.TextBox();
            this.preWaterHazards = new System.Windows.Forms.TextBox();
            this.preWaterObstructions = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.preLightning = new System.Windows.Forms.ComboBox();
            this.preAccess = new System.Windows.Forms.TextBox();
            this.preOtherThreats = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.preOperationObjectives = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.prePersonnelInvolved = new System.Windows.Forms.TextBox();
            this.preVehiclesInvolved = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.prePrimaryRadioChannel = new System.Windows.Forms.TextBox();
            this.preSecondaryRadioChannel = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.prePrimarySubsurfaceChannel = new System.Windows.Forms.TextBox();
            this.preSecondarySubsurfaceChannel = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.preStandardDiveGear = new System.Windows.Forms.CheckBox();
            this.preSrandardSwiftwaterGear = new System.Windows.Forms.CheckBox();
            this.preStandardTenderGear = new System.Windows.Forms.CheckBox();
            this.preStandardIceRescueGear = new System.Windows.Forms.CheckBox();
            this.preOtherGear = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.prePatrolSupervisor = new System.Windows.Forms.CheckBox();
            this.preAvistaGCC = new System.Windows.Forms.CheckBox();
            this.preDispatch = new System.Windows.Forms.CheckBox();
            this.preUpriverDam = new System.Windows.Forms.CheckBox();
            this.preDeaconessHyperbaricChamber = new System.Windows.Forms.CheckBox();
            this.preShiftCommander = new System.Windows.Forms.CheckBox();
            this.preOtherNotifications = new System.Windows.Forms.CheckBox();
            this.preDiveLabel = new System.Windows.Forms.Label();
            this.postDivePanel = new System.Windows.Forms.Panel();
            this.postDiveFormPanel = new System.Windows.Forms.Panel();
            this.debriefTable = new System.Windows.Forms.TableLayoutPanel();
            this.debriefVesselLabel = new System.Windows.Forms.Label();
            this.debriefVesselText = new System.Windows.Forms.TextBox();
            this.debriefDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.debriefEquipmentText = new System.Windows.Forms.TextBox();
            this.debriefDateTimeLabel = new System.Windows.Forms.Label();
            this.debriefEquipmentLabel = new System.Windows.Forms.Label();
            this.debriefInjuriesLabel = new System.Windows.Forms.Label();
            this.debriefInjuriesText = new System.Windows.Forms.TextBox();
            this.debriefPropertyText = new System.Windows.Forms.TextBox();
            this.debriefPropertyLabel = new System.Windows.Forms.Label();
            this.debriefPropertySupervisorLabel = new System.Windows.Forms.Label();
            this.debriefPropertySupervisorCombo = new System.Windows.Forms.ComboBox();
            this.debriefInjuriesSupervisorCombo = new System.Windows.Forms.ComboBox();
            this.debriefInjuriesSupervisorLabel = new System.Windows.Forms.Label();
            this.debriefWorkedWellLabel = new System.Windows.Forms.Label();
            this.debriefNotWorkedWellLabel = new System.Windows.Forms.Label();
            this.debriefWorkedWellText = new System.Windows.Forms.TextBox();
            this.debriefNotWorkedWellText = new System.Windows.Forms.TextBox();
            this.postDiveLabel = new System.Windows.Forms.Label();
            this.activeDivePanel = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.activeDiveTable = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.radioButton75 = new System.Windows.Forms.RadioButton();
            this.radioButton74 = new System.Windows.Forms.RadioButton();
            this.radioButton73 = new System.Windows.Forms.RadioButton();
            this.radioButton72 = new System.Windows.Forms.RadioButton();
            this.radioButton71 = new System.Windows.Forms.RadioButton();
            this.radioButton70 = new System.Windows.Forms.RadioButton();
            this.radioButton69 = new System.Windows.Forms.RadioButton();
            this.radioButton78 = new System.Windows.Forms.RadioButton();
            this.radioButton77 = new System.Windows.Forms.RadioButton();
            this.radioButton76 = new System.Windows.Forms.RadioButton();
            this.label133 = new System.Windows.Forms.Label();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label135 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label136 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label137 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.toolbar.SuspendLayout();
            this.startPanel.SuspendLayout();
            this.startPanelForm.SuspendLayout();
            this.diverLogPanel.SuspendLayout();
            this.diverLogFormPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.reportPanel.SuspendLayout();
            this.preDivePanel.SuspendLayout();
            this.preDiveFormPanel.SuspendLayout();
            this.preDiveTable.SuspendLayout();
            this.postDivePanel.SuspendLayout();
            this.postDiveFormPanel.SuspendLayout();
            this.debriefTable.SuspendLayout();
            this.activeDivePanel.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.activeDiveTable.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolbar
            // 
            this.toolbar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.helpToolStripButton});
            this.toolbar.Location = new System.Drawing.Point(0, 0);
            this.toolbar.Name = "toolbar";
            this.toolbar.Size = new System.Drawing.Size(1339, 27);
            this.toolbar.TabIndex = 0;
            this.toolbar.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.newToolStripButton.Text = "&New Dive";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.openToolStripButton.Text = "&Open Dive";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.saveToolStripButton.Text = "&Save Dive";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.printToolStripButton.Text = "&Print";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(24, 24);
            this.helpToolStripButton.Text = "He&lp";
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.DimGray;
            this.startButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.startButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.startButton.Location = new System.Drawing.Point(4, 34);
            this.startButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(160, 135);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // diverLogButton
            // 
            this.diverLogButton.BackColor = System.Drawing.Color.DimGray;
            this.diverLogButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.diverLogButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.diverLogButton.Location = new System.Drawing.Point(4, 177);
            this.diverLogButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.diverLogButton.Name = "diverLogButton";
            this.diverLogButton.Size = new System.Drawing.Size(160, 135);
            this.diverLogButton.TabIndex = 2;
            this.diverLogButton.Text = "Diver Log";
            this.diverLogButton.UseVisualStyleBackColor = false;
            this.diverLogButton.Click += new System.EventHandler(this.diverLogButton_Click);
            // 
            // reportButton
            // 
            this.reportButton.BackColor = System.Drawing.Color.DimGray;
            this.reportButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.reportButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.reportButton.Location = new System.Drawing.Point(4, 320);
            this.reportButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.reportButton.Name = "reportButton";
            this.reportButton.Size = new System.Drawing.Size(160, 135);
            this.reportButton.TabIndex = 3;
            this.reportButton.Text = "Report";
            this.reportButton.UseVisualStyleBackColor = false;
            this.reportButton.Click += new System.EventHandler(this.reportButton_Click);
            // 
            // preDiveButton
            // 
            this.preDiveButton.BackColor = System.Drawing.Color.DimGray;
            this.preDiveButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.preDiveButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.preDiveButton.Location = new System.Drawing.Point(4, 463);
            this.preDiveButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.preDiveButton.Name = "preDiveButton";
            this.preDiveButton.Size = new System.Drawing.Size(160, 135);
            this.preDiveButton.TabIndex = 4;
            this.preDiveButton.Text = "Pre Dive";
            this.preDiveButton.UseVisualStyleBackColor = false;
            this.preDiveButton.Click += new System.EventHandler(this.preDiveButton_Click);
            // 
            // activeDiveButton
            // 
            this.activeDiveButton.BackColor = System.Drawing.Color.DimGray;
            this.activeDiveButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.activeDiveButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.activeDiveButton.Location = new System.Drawing.Point(4, 606);
            this.activeDiveButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.activeDiveButton.Name = "activeDiveButton";
            this.activeDiveButton.Size = new System.Drawing.Size(160, 135);
            this.activeDiveButton.TabIndex = 5;
            this.activeDiveButton.Text = "Active Dive";
            this.activeDiveButton.UseVisualStyleBackColor = false;
            this.activeDiveButton.Click += new System.EventHandler(this.activeDiveButton_Click);
            // 
            // postDiveButton
            // 
            this.postDiveButton.BackColor = System.Drawing.Color.DimGray;
            this.postDiveButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.postDiveButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.postDiveButton.Location = new System.Drawing.Point(4, 748);
            this.postDiveButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.postDiveButton.Name = "postDiveButton";
            this.postDiveButton.Size = new System.Drawing.Size(160, 135);
            this.postDiveButton.TabIndex = 6;
            this.postDiveButton.Text = "Post Dive";
            this.postDiveButton.UseVisualStyleBackColor = false;
            this.postDiveButton.Click += new System.EventHandler(this.postDiveButton_Click);
            // 
            // startPanel
            // 
            this.startPanel.BackColor = System.Drawing.Color.DimGray;
            this.startPanel.Controls.Add(this.startPanelForm);
            this.startPanel.Controls.Add(this.startLabel);
            this.startPanel.Location = new System.Drawing.Point(168, 34);
            this.startPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.startPanel.Name = "startPanel";
            this.startPanel.Size = new System.Drawing.Size(1160, 849);
            this.startPanel.TabIndex = 7;
            this.startPanel.Visible = false;
            this.startPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.startPanel_Paint);
            // 
            // startPanelForm
            // 
            this.startPanelForm.AutoScroll = true;
            this.startPanelForm.BackColor = System.Drawing.Color.Gray;
            this.startPanelForm.Controls.Add(this.button12);
            this.startPanelForm.Controls.Add(this.button11);
            this.startPanelForm.Location = new System.Drawing.Point(0, 43);
            this.startPanelForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.startPanelForm.Name = "startPanelForm";
            this.startPanelForm.Size = new System.Drawing.Size(1160, 806);
            this.startPanelForm.TabIndex = 4;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DimGray;
            this.button12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(377, 421);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(403, 135);
            this.button12.TabIndex = 3;
            this.button12.Text = "Load Incident";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DimGray;
            this.button11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(377, 149);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(397, 137);
            this.button11.TabIndex = 2;
            this.button11.Text = "Start New Dive";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // startLabel
            // 
            this.startLabel.AutoSize = true;
            this.startLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel.ForeColor = System.Drawing.Color.White;
            this.startLabel.Location = new System.Drawing.Point(4, 0);
            this.startLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.startLabel.Name = "startLabel";
            this.startLabel.Size = new System.Drawing.Size(99, 39);
            this.startLabel.TabIndex = 1;
            this.startLabel.Text = "Start";
            // 
            // diverLogPanel
            // 
            this.diverLogPanel.BackColor = System.Drawing.Color.DimGray;
            this.diverLogPanel.Controls.Add(this.diverLogFormPanel);
            this.diverLogPanel.Controls.Add(this.diverLogLabel);
            this.diverLogPanel.Location = new System.Drawing.Point(168, 34);
            this.diverLogPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.diverLogPanel.Name = "diverLogPanel";
            this.diverLogPanel.Size = new System.Drawing.Size(1160, 849);
            this.diverLogPanel.TabIndex = 1;
            this.diverLogPanel.Visible = false;
            // 
            // diverLogFormPanel
            // 
            this.diverLogFormPanel.AutoScroll = true;
            this.diverLogFormPanel.BackColor = System.Drawing.Color.Gray;
            this.diverLogFormPanel.Controls.Add(this.removeDiver);
            this.diverLogFormPanel.Controls.Add(this.diverList);
            this.diverLogFormPanel.Controls.Add(this.diverName);
            this.diverLogFormPanel.Controls.Add(this.addDiver);
            this.diverLogFormPanel.Location = new System.Drawing.Point(0, 43);
            this.diverLogFormPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.diverLogFormPanel.Name = "diverLogFormPanel";
            this.diverLogFormPanel.Size = new System.Drawing.Size(1160, 806);
            this.diverLogFormPanel.TabIndex = 3;
            // 
            // removeDiver
            // 
            this.removeDiver.BackColor = System.Drawing.Color.DimGray;
            this.removeDiver.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.removeDiver.ForeColor = System.Drawing.Color.White;
            this.removeDiver.Location = new System.Drawing.Point(768, 734);
            this.removeDiver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.removeDiver.Name = "removeDiver";
            this.removeDiver.Size = new System.Drawing.Size(365, 50);
            this.removeDiver.TabIndex = 4;
            this.removeDiver.Text = "Remove a Diver";
            this.removeDiver.UseVisualStyleBackColor = false;
            this.removeDiver.Click += new System.EventHandler(this.removeDiver_Click);
            // 
            // diverList
            // 
            this.diverList.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.diverList.Location = new System.Drawing.Point(39, 47);
            this.diverList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.diverList.Multiline = true;
            this.diverList.Name = "diverList";
            this.diverList.ReadOnly = true;
            this.diverList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.diverList.Size = new System.Drawing.Size(1089, 579);
            this.diverList.TabIndex = 3;
            // 
            // diverName
            // 
            this.diverName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.diverName.Location = new System.Drawing.Point(39, 657);
            this.diverName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.diverName.Name = "diverName";
            this.diverName.Size = new System.Drawing.Size(679, 47);
            this.diverName.TabIndex = 2;
            this.diverName.TextChanged += new System.EventHandler(this.diverName_TextChanged);
            // 
            // addDiver
            // 
            this.addDiver.BackColor = System.Drawing.Color.DimGray;
            this.addDiver.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F);
            this.addDiver.ForeColor = System.Drawing.Color.White;
            this.addDiver.Location = new System.Drawing.Point(768, 656);
            this.addDiver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addDiver.Name = "addDiver";
            this.addDiver.Size = new System.Drawing.Size(365, 50);
            this.addDiver.TabIndex = 1;
            this.addDiver.Text = "Add New Diver";
            this.addDiver.UseVisualStyleBackColor = false;
            this.addDiver.Click += new System.EventHandler(this.addDiver_Click);
            // 
            // diverLogLabel
            // 
            this.diverLogLabel.AutoSize = true;
            this.diverLogLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diverLogLabel.ForeColor = System.Drawing.Color.White;
            this.diverLogLabel.Location = new System.Drawing.Point(4, 0);
            this.diverLogLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.diverLogLabel.Name = "diverLogLabel";
            this.diverLogLabel.Size = new System.Drawing.Size(176, 39);
            this.diverLogLabel.TabIndex = 2;
            this.diverLogLabel.Text = "Diver Log";
            // 
            // reportPanel
            // 
            this.reportPanel.BackColor = System.Drawing.Color.DimGray;
            this.reportPanel.Controls.Add(this.reportFormPanel);
            this.reportPanel.Controls.Add(this.reportLabel);
            this.reportPanel.Location = new System.Drawing.Point(168, 34);
            this.reportPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.reportPanel.Name = "reportPanel";
            this.reportPanel.Size = new System.Drawing.Size(1160, 849);
            this.reportPanel.TabIndex = 1;
            this.reportPanel.Visible = false;
            // 
            // reportFormPanel
            // 
            this.reportFormPanel.AutoScroll = true;
            this.reportFormPanel.BackColor = System.Drawing.Color.Gray;
            this.reportFormPanel.Location = new System.Drawing.Point(0, 43);
            this.reportFormPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.reportFormPanel.Name = "reportFormPanel";
            this.reportFormPanel.Size = new System.Drawing.Size(1160, 806);
            this.reportFormPanel.TabIndex = 4;
            // 
            // reportLabel
            // 
            this.reportLabel.AutoSize = true;
            this.reportLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportLabel.ForeColor = System.Drawing.Color.White;
            this.reportLabel.Location = new System.Drawing.Point(4, 0);
            this.reportLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.reportLabel.Name = "reportLabel";
            this.reportLabel.Size = new System.Drawing.Size(130, 39);
            this.reportLabel.TabIndex = 2;
            this.reportLabel.Text = "Report";
            // 
            // preDivePanel
            // 
            this.preDivePanel.BackColor = System.Drawing.Color.DimGray;
            this.preDivePanel.Controls.Add(this.preDiveFormPanel);
            this.preDivePanel.Controls.Add(this.preDiveLabel);
            this.preDivePanel.ForeColor = System.Drawing.Color.White;
            this.preDivePanel.Location = new System.Drawing.Point(168, 34);
            this.preDivePanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.preDivePanel.Name = "preDivePanel";
            this.preDivePanel.Size = new System.Drawing.Size(1160, 849);
            this.preDivePanel.TabIndex = 8;
            this.preDivePanel.Visible = false;
            // 
            // preDiveFormPanel
            // 
            this.preDiveFormPanel.AutoScroll = true;
            this.preDiveFormPanel.BackColor = System.Drawing.Color.Gray;
            this.preDiveFormPanel.Controls.Add(this.preDiveTable);
            this.preDiveFormPanel.Location = new System.Drawing.Point(0, 43);
            this.preDiveFormPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.preDiveFormPanel.Name = "preDiveFormPanel";
            this.preDiveFormPanel.Size = new System.Drawing.Size(1160, 806);
            this.preDiveFormPanel.TabIndex = 5;
            // 
            // preDiveTable
            // 
            this.preDiveTable.ColumnCount = 3;
            this.preDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.preDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.preDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.preDiveTable.Controls.Add(this.preReportLabel, 0, 2);
            this.preDiveTable.Controls.Add(this.preDateTimePicker, 2, 0);
            this.preDiveTable.Controls.Add(this.label8, 0, 0);
            this.preDiveTable.Controls.Add(this.preReportNum, 0, 3);
            this.preDiveTable.Controls.Add(this.preStateMissionLabel, 2, 2);
            this.preDiveTable.Controls.Add(this.preStateMissionNum, 2, 3);
            this.preDiveTable.Controls.Add(this.preOpCompletionLabel, 0, 5);
            this.preDiveTable.Controls.Add(this.preCaseInvestigatorLabel, 2, 5);
            this.preDiveTable.Controls.Add(this.preOpPlanCompletedBy, 0, 6);
            this.preDiveTable.Controls.Add(this.preCaseInvestigator, 2, 6);
            this.preDiveTable.Controls.Add(this.label13, 0, 8);
            this.preDiveTable.Controls.Add(this.preBriefingLocation, 0, 9);
            this.preDiveTable.Controls.Add(this.label14, 0, 11);
            this.preDiveTable.Controls.Add(this.preSituation, 0, 12);
            this.preDiveTable.Controls.Add(this.label15, 2, 11);
            this.preDiveTable.Controls.Add(this.preTypeOfOperation, 2, 12);
            this.preDiveTable.Controls.Add(this.label16, 0, 14);
            this.preDiveTable.Controls.Add(this.preAnticipatedDate, 0, 15);
            this.preDiveTable.Controls.Add(this.label17, 2, 14);
            this.preDiveTable.Controls.Add(this.preAnticipatedTime, 2, 15);
            this.preDiveTable.Controls.Add(this.label18, 0, 17);
            this.preDiveTable.Controls.Add(this.preLocationAndDescription, 0, 18);
            this.preDiveTable.Controls.Add(this.label19, 0, 20);
            this.preDiveTable.Controls.Add(this.preSiteSurvey, 0, 21);
            this.preDiveTable.Controls.Add(this.label20, 0, 23);
            this.preDiveTable.Controls.Add(this.label21, 0, 24);
            this.preDiveTable.Controls.Add(this.preWitnessName, 0, 25);
            this.preDiveTable.Controls.Add(this.label22, 0, 26);
            this.preDiveTable.Controls.Add(this.preWitnessPhone, 0, 27);
            this.preDiveTable.Controls.Add(this.label23, 2, 24);
            this.preDiveTable.Controls.Add(this.preWitnessAddress, 2, 25);
            this.preDiveTable.Controls.Add(this.label25, 0, 30);
            this.preDiveTable.Controls.Add(this.label26, 2, 30);
            this.preDiveTable.Controls.Add(this.label27, 0, 32);
            this.preDiveTable.Controls.Add(this.label28, 2, 32);
            this.preDiveTable.Controls.Add(this.label29, 0, 34);
            this.preDiveTable.Controls.Add(this.preVehicleMake, 0, 31);
            this.preDiveTable.Controls.Add(this.preVehicleModel, 2, 31);
            this.preDiveTable.Controls.Add(this.preVehicleYear, 0, 33);
            this.preDiveTable.Controls.Add(this.preVehicleColor, 2, 33);
            this.preDiveTable.Controls.Add(this.preVehiclePlate, 0, 35);
            this.preDiveTable.Controls.Add(this.label24, 0, 29);
            this.preDiveTable.Controls.Add(this.label30, 0, 37);
            this.preDiveTable.Controls.Add(this.preSceneAssessment, 0, 38);
            this.preDiveTable.Controls.Add(this.label31, 0, 40);
            this.preDiveTable.Controls.Add(this.label32, 0, 41);
            this.preDiveTable.Controls.Add(this.label35, 0, 43);
            this.preDiveTable.Controls.Add(this.label34, 2, 41);
            this.preDiveTable.Controls.Add(this.label37, 0, 45);
            this.preDiveTable.Controls.Add(this.label33, 2, 45);
            this.preDiveTable.Controls.Add(this.label36, 0, 47);
            this.preDiveTable.Controls.Add(this.preWaterFlow, 0, 42);
            this.preDiveTable.Controls.Add(this.preWaterDepth, 0, 48);
            this.preDiveTable.Controls.Add(this.preWaterTemp, 0, 46);
            this.preDiveTable.Controls.Add(this.preWaterVisibility, 0, 44);
            this.preDiveTable.Controls.Add(this.preWaterHazards, 2, 46);
            this.preDiveTable.Controls.Add(this.preWaterObstructions, 2, 42);
            this.preDiveTable.Controls.Add(this.label39, 0, 50);
            this.preDiveTable.Controls.Add(this.label40, 2, 50);
            this.preDiveTable.Controls.Add(this.label38, 0, 53);
            this.preDiveTable.Controls.Add(this.preLightning, 0, 51);
            this.preDiveTable.Controls.Add(this.preAccess, 2, 51);
            this.preDiveTable.Controls.Add(this.preOtherThreats, 0, 54);
            this.preDiveTable.Controls.Add(this.label41, 0, 56);
            this.preDiveTable.Controls.Add(this.preOperationObjectives, 0, 57);
            this.preDiveTable.Controls.Add(this.label42, 0, 59);
            this.preDiveTable.Controls.Add(this.label43, 2, 59);
            this.preDiveTable.Controls.Add(this.prePersonnelInvolved, 0, 60);
            this.preDiveTable.Controls.Add(this.preVehiclesInvolved, 2, 60);
            this.preDiveTable.Controls.Add(this.label44, 0, 62);
            this.preDiveTable.Controls.Add(this.label45, 0, 63);
            this.preDiveTable.Controls.Add(this.label46, 2, 63);
            this.preDiveTable.Controls.Add(this.prePrimaryRadioChannel, 0, 64);
            this.preDiveTable.Controls.Add(this.preSecondaryRadioChannel, 2, 64);
            this.preDiveTable.Controls.Add(this.label47, 0, 65);
            this.preDiveTable.Controls.Add(this.prePrimarySubsurfaceChannel, 0, 66);
            this.preDiveTable.Controls.Add(this.preSecondarySubsurfaceChannel, 2, 66);
            this.preDiveTable.Controls.Add(this.label48, 2, 65);
            this.preDiveTable.Controls.Add(this.label2, 0, 68);
            this.preDiveTable.Controls.Add(this.preStandardDiveGear, 0, 69);
            this.preDiveTable.Controls.Add(this.preSrandardSwiftwaterGear, 2, 68);
            this.preDiveTable.Controls.Add(this.preStandardTenderGear, 0, 70);
            this.preDiveTable.Controls.Add(this.preStandardIceRescueGear, 2, 69);
            this.preDiveTable.Controls.Add(this.preOtherGear, 2, 70);
            this.preDiveTable.Controls.Add(this.label3, 0, 72);
            this.preDiveTable.Controls.Add(this.prePatrolSupervisor, 0, 73);
            this.preDiveTable.Controls.Add(this.preAvistaGCC, 2, 72);
            this.preDiveTable.Controls.Add(this.preDispatch, 0, 74);
            this.preDiveTable.Controls.Add(this.preUpriverDam, 2, 73);
            this.preDiveTable.Controls.Add(this.preDeaconessHyperbaricChamber, 2, 74);
            this.preDiveTable.Controls.Add(this.preShiftCommander, 0, 75);
            this.preDiveTable.Controls.Add(this.preOtherNotifications, 2, 75);
            this.preDiveTable.Location = new System.Drawing.Point(13, 20);
            this.preDiveTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preDiveTable.Name = "preDiveTable";
            this.preDiveTable.RowCount = 77;
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.preDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.preDiveTable.Size = new System.Drawing.Size(1124, 2859);
            this.preDiveTable.TabIndex = 4;
            // 
            // preReportLabel
            // 
            this.preReportLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preReportLabel.AutoSize = true;
            this.preReportLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preReportLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.preReportLabel.Location = new System.Drawing.Point(3, 70);
            this.preReportLabel.Name = "preReportLabel";
            this.preReportLabel.Size = new System.Drawing.Size(314, 28);
            this.preReportLabel.TabIndex = 1;
            this.preReportLabel.Text = "Incident Number (Report):";
            // 
            // preDateTimePicker
            // 
            this.preDateTimePicker.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preDateTimePicker.Location = new System.Drawing.Point(575, 2);
            this.preDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preDateTimePicker.Name = "preDateTimePicker";
            this.preDateTimePicker.Size = new System.Drawing.Size(545, 31);
            this.preDateTimePicker.TabIndex = 2;
            this.preDateTimePicker.ValueChanged += new System.EventHandler(this.preDateTimePicker_ValueChanged);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(206, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 28);
            this.label8.TabIndex = 3;
            this.label8.Text = "Date/Time:";
            // 
            // preReportNum
            // 
            this.preReportNum.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preReportNum.Location = new System.Drawing.Point(3, 100);
            this.preReportNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preReportNum.Name = "preReportNum";
            this.preReportNum.Size = new System.Drawing.Size(544, 34);
            this.preReportNum.TabIndex = 2;
            this.preReportNum.TextChanged += new System.EventHandler(this.preReportNum_TextChanged);
            // 
            // preStateMissionLabel
            // 
            this.preStateMissionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preStateMissionLabel.AutoSize = true;
            this.preStateMissionLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preStateMissionLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.preStateMissionLabel.Location = new System.Drawing.Point(575, 70);
            this.preStateMissionLabel.Name = "preStateMissionLabel";
            this.preStateMissionLabel.Size = new System.Drawing.Size(273, 28);
            this.preStateMissionLabel.TabIndex = 3;
            this.preStateMissionLabel.Text = "State Mission Number:";
            // 
            // preStateMissionNum
            // 
            this.preStateMissionNum.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preStateMissionNum.Location = new System.Drawing.Point(575, 100);
            this.preStateMissionNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preStateMissionNum.Name = "preStateMissionNum";
            this.preStateMissionNum.Size = new System.Drawing.Size(544, 34);
            this.preStateMissionNum.TabIndex = 4;
            this.preStateMissionNum.TextChanged += new System.EventHandler(this.preStateMissionNum_TextChanged);
            // 
            // preOpCompletionLabel
            // 
            this.preOpCompletionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preOpCompletionLabel.AutoSize = true;
            this.preOpCompletionLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preOpCompletionLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.preOpCompletionLabel.Location = new System.Drawing.Point(3, 168);
            this.preOpCompletionLabel.Name = "preOpCompletionLabel";
            this.preOpCompletionLabel.Size = new System.Drawing.Size(280, 28);
            this.preOpCompletionLabel.TabIndex = 5;
            this.preOpCompletionLabel.Text = "OP Plan Completed By:";
            // 
            // preCaseInvestigatorLabel
            // 
            this.preCaseInvestigatorLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preCaseInvestigatorLabel.AutoSize = true;
            this.preCaseInvestigatorLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preCaseInvestigatorLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.preCaseInvestigatorLabel.Location = new System.Drawing.Point(575, 168);
            this.preCaseInvestigatorLabel.Name = "preCaseInvestigatorLabel";
            this.preCaseInvestigatorLabel.Size = new System.Drawing.Size(224, 28);
            this.preCaseInvestigatorLabel.TabIndex = 6;
            this.preCaseInvestigatorLabel.Text = "Case Investigator:";
            // 
            // preOpPlanCompletedBy
            // 
            this.preOpPlanCompletedBy.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preOpPlanCompletedBy.Location = new System.Drawing.Point(3, 198);
            this.preOpPlanCompletedBy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preOpPlanCompletedBy.Name = "preOpPlanCompletedBy";
            this.preOpPlanCompletedBy.Size = new System.Drawing.Size(544, 34);
            this.preOpPlanCompletedBy.TabIndex = 7;
            this.preOpPlanCompletedBy.TextChanged += new System.EventHandler(this.preOpPlanCompletedBy_TextChanged);
            // 
            // preCaseInvestigator
            // 
            this.preCaseInvestigator.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preCaseInvestigator.Location = new System.Drawing.Point(575, 198);
            this.preCaseInvestigator.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preCaseInvestigator.Name = "preCaseInvestigator";
            this.preCaseInvestigator.Size = new System.Drawing.Size(544, 34);
            this.preCaseInvestigator.TabIndex = 8;
            this.preCaseInvestigator.TextChanged += new System.EventHandler(this.preCaseInvestigator_TextChanged);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(3, 266);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(314, 28);
            this.label13.TabIndex = 9;
            this.label13.Text = "Breifing/Staging Location:";
            // 
            // preBriefingLocation
            // 
            this.preDiveTable.SetColumnSpan(this.preBriefingLocation, 3);
            this.preBriefingLocation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preBriefingLocation.Location = new System.Drawing.Point(3, 296);
            this.preBriefingLocation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preBriefingLocation.Multiline = true;
            this.preBriefingLocation.Name = "preBriefingLocation";
            this.preBriefingLocation.Size = new System.Drawing.Size(1117, 74);
            this.preBriefingLocation.TabIndex = 10;
            this.preBriefingLocation.TextChanged += new System.EventHandler(this.preBriefingLocation_TextChanged);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(3, 405);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(122, 28);
            this.label14.TabIndex = 11;
            this.label14.Text = "Situation:";
            // 
            // preSituation
            // 
            this.preSituation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preSituation.FormattingEnabled = true;
            this.preSituation.Items.AddRange(new object[] {
            "OP Plan",
            "Training"});
            this.preSituation.Location = new System.Drawing.Point(3, 435);
            this.preSituation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSituation.Name = "preSituation";
            this.preSituation.Size = new System.Drawing.Size(544, 35);
            this.preSituation.TabIndex = 12;
            this.preSituation.SelectedIndexChanged += new System.EventHandler(this.preSituation_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(575, 405);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(227, 28);
            this.label15.TabIndex = 13;
            this.label15.Text = "Type of Operation:";
            // 
            // preTypeOfOperation
            // 
            this.preTypeOfOperation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preTypeOfOperation.FormattingEnabled = true;
            this.preTypeOfOperation.Items.AddRange(new object[] {
            "Evidence Recovery",
            "Body Recovery",
            "Other"});
            this.preTypeOfOperation.Location = new System.Drawing.Point(575, 435);
            this.preTypeOfOperation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preTypeOfOperation.Name = "preTypeOfOperation";
            this.preTypeOfOperation.Size = new System.Drawing.Size(544, 35);
            this.preTypeOfOperation.TabIndex = 14;
            this.preTypeOfOperation.SelectedIndexChanged += new System.EventHandler(this.preTypeOfOperation_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(3, 503);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(213, 28);
            this.label16.TabIndex = 15;
            this.label16.Text = "Anticipated Date:";
            // 
            // preAnticipatedDate
            // 
            this.preAnticipatedDate.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preAnticipatedDate.Location = new System.Drawing.Point(3, 533);
            this.preAnticipatedDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preAnticipatedDate.Mask = "00/00/0000";
            this.preAnticipatedDate.Name = "preAnticipatedDate";
            this.preAnticipatedDate.Size = new System.Drawing.Size(544, 34);
            this.preAnticipatedDate.TabIndex = 16;
            this.preAnticipatedDate.ValidatingType = typeof(System.DateTime);
            this.preAnticipatedDate.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.preAnticipatedDate_MaskInputRejected);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(575, 503);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(325, 28);
            this.label17.TabIndex = 17;
            this.label17.Text = "Anticipated Time (Military):";
            // 
            // preAnticipatedTime
            // 
            this.preAnticipatedTime.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preAnticipatedTime.Location = new System.Drawing.Point(575, 533);
            this.preAnticipatedTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preAnticipatedTime.Mask = "00:00";
            this.preAnticipatedTime.Name = "preAnticipatedTime";
            this.preAnticipatedTime.Size = new System.Drawing.Size(544, 34);
            this.preAnticipatedTime.TabIndex = 18;
            this.preAnticipatedTime.ValidatingType = typeof(System.DateTime);
            this.preAnticipatedTime.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.preAnticipatedTime_MaskInputRejected);
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(3, 601);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(495, 28);
            this.label18.TabIndex = 19;
            this.label18.Text = "Location(s) of Incident and Description(s):";
            // 
            // preLocationAndDescription
            // 
            this.preDiveTable.SetColumnSpan(this.preLocationAndDescription, 3);
            this.preLocationAndDescription.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preLocationAndDescription.Location = new System.Drawing.Point(3, 631);
            this.preLocationAndDescription.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preLocationAndDescription.Multiline = true;
            this.preLocationAndDescription.Name = "preLocationAndDescription";
            this.preLocationAndDescription.Size = new System.Drawing.Size(1117, 74);
            this.preLocationAndDescription.TabIndex = 20;
            this.preLocationAndDescription.TextChanged += new System.EventHandler(this.preLocationAndDescription_TextChanged);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(3, 740);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(266, 28);
            this.label19.TabIndex = 21;
            this.label19.Text = "Site Survey By Whom:";
            // 
            // preSiteSurvey
            // 
            this.preDiveTable.SetColumnSpan(this.preSiteSurvey, 3);
            this.preSiteSurvey.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preSiteSurvey.Location = new System.Drawing.Point(3, 770);
            this.preSiteSurvey.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSiteSurvey.Multiline = true;
            this.preSiteSurvey.Name = "preSiteSurvey";
            this.preSiteSurvey.Size = new System.Drawing.Size(1117, 34);
            this.preSiteSurvey.TabIndex = 22;
            this.preSiteSurvey.TextChanged += new System.EventHandler(this.preSiteSurvey_TextChanged);
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(3, 838);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(278, 28);
            this.label20.TabIndex = 23;
            this.label20.Text = "Witness (Suspect) Info:";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(3, 877);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(87, 28);
            this.label21.TabIndex = 24;
            this.label21.Text = "Name:";
            // 
            // preWitnessName
            // 
            this.preWitnessName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWitnessName.Location = new System.Drawing.Point(3, 907);
            this.preWitnessName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWitnessName.Name = "preWitnessName";
            this.preWitnessName.Size = new System.Drawing.Size(544, 34);
            this.preWitnessName.TabIndex = 25;
            this.preWitnessName.TextChanged += new System.EventHandler(this.preWitnessName_TextChanged);
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(3, 955);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(188, 28);
            this.label22.TabIndex = 26;
            this.label22.Text = "Contact Phone:";
            // 
            // preWitnessPhone
            // 
            this.preWitnessPhone.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWitnessPhone.Location = new System.Drawing.Point(3, 985);
            this.preWitnessPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWitnessPhone.Mask = "(999) 000-0000";
            this.preWitnessPhone.Name = "preWitnessPhone";
            this.preWitnessPhone.Size = new System.Drawing.Size(544, 34);
            this.preWitnessPhone.TabIndex = 27;
            this.preWitnessPhone.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.preWitnessPhone_MaskInputRejected);
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(575, 877);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(118, 28);
            this.label23.TabIndex = 28;
            this.label23.Text = "Address:";
            // 
            // preWitnessAddress
            // 
            this.preWitnessAddress.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWitnessAddress.Location = new System.Drawing.Point(575, 907);
            this.preWitnessAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWitnessAddress.Multiline = true;
            this.preWitnessAddress.Name = "preWitnessAddress";
            this.preDiveTable.SetRowSpan(this.preWitnessAddress, 3);
            this.preWitnessAddress.Size = new System.Drawing.Size(544, 112);
            this.preWitnessAddress.TabIndex = 29;
            this.preWitnessAddress.TextChanged += new System.EventHandler(this.preWitnessAddress_TextChanged);
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(3, 1092);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 28);
            this.label25.TabIndex = 31;
            this.label25.Text = "Make:";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(575, 1092);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 28);
            this.label26.TabIndex = 32;
            this.label26.Text = "Model:";
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label27.Location = new System.Drawing.Point(3, 1170);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 28);
            this.label27.TabIndex = 33;
            this.label27.Text = "Year:";
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label28.Location = new System.Drawing.Point(575, 1170);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(84, 28);
            this.label28.TabIndex = 34;
            this.label28.Text = "Color:";
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label29.Location = new System.Drawing.Point(3, 1248);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(178, 28);
            this.label29.TabIndex = 35;
            this.label29.Text = "Plate Number:";
            // 
            // preVehicleMake
            // 
            this.preVehicleMake.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehicleMake.Location = new System.Drawing.Point(3, 1122);
            this.preVehicleMake.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehicleMake.Name = "preVehicleMake";
            this.preVehicleMake.Size = new System.Drawing.Size(544, 34);
            this.preVehicleMake.TabIndex = 36;
            this.preVehicleMake.TextChanged += new System.EventHandler(this.preVehicleMake_TextChanged);
            // 
            // preVehicleModel
            // 
            this.preVehicleModel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehicleModel.Location = new System.Drawing.Point(575, 1122);
            this.preVehicleModel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehicleModel.Name = "preVehicleModel";
            this.preVehicleModel.Size = new System.Drawing.Size(544, 34);
            this.preVehicleModel.TabIndex = 37;
            this.preVehicleModel.TextChanged += new System.EventHandler(this.preVehicleModel_TextChanged);
            // 
            // preVehicleYear
            // 
            this.preVehicleYear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehicleYear.Location = new System.Drawing.Point(3, 1200);
            this.preVehicleYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehicleYear.Name = "preVehicleYear";
            this.preVehicleYear.Size = new System.Drawing.Size(544, 34);
            this.preVehicleYear.TabIndex = 38;
            this.preVehicleYear.TextChanged += new System.EventHandler(this.preVehicleYear_TextChanged);
            // 
            // preVehicleColor
            // 
            this.preVehicleColor.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehicleColor.Location = new System.Drawing.Point(575, 1200);
            this.preVehicleColor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehicleColor.Name = "preVehicleColor";
            this.preVehicleColor.Size = new System.Drawing.Size(544, 34);
            this.preVehicleColor.TabIndex = 39;
            this.preVehicleColor.TextChanged += new System.EventHandler(this.preVehicleColor_TextChanged);
            // 
            // preVehiclePlate
            // 
            this.preVehiclePlate.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehiclePlate.Location = new System.Drawing.Point(3, 1278);
            this.preVehiclePlate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehiclePlate.Name = "preVehiclePlate";
            this.preVehiclePlate.Size = new System.Drawing.Size(544, 34);
            this.preVehiclePlate.TabIndex = 40;
            this.preVehiclePlate.TextChanged += new System.EventHandler(this.preVehiclePlate_TextChanged);
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(3, 1053);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(309, 28);
            this.label24.TabIndex = 30;
            this.label24.Text = "Known Vehicle Recovery:";
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label30.Location = new System.Drawing.Point(3, 1346);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(238, 28);
            this.label30.TabIndex = 41;
            this.label30.Text = "Scene Assessment:";
            // 
            // preSceneAssessment
            // 
            this.preDiveTable.SetColumnSpan(this.preSceneAssessment, 3);
            this.preSceneAssessment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preSceneAssessment.Location = new System.Drawing.Point(3, 1376);
            this.preSceneAssessment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSceneAssessment.Multiline = true;
            this.preSceneAssessment.Name = "preSceneAssessment";
            this.preSceneAssessment.Size = new System.Drawing.Size(1117, 34);
            this.preSceneAssessment.TabIndex = 42;
            this.preSceneAssessment.TextChanged += new System.EventHandler(this.preSceneAssessment_TextChanged);
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label31.Location = new System.Drawing.Point(3, 1444);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(236, 28);
            this.label31.TabIndex = 43;
            this.label31.Text = "Water Condition(s):";
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label32.Location = new System.Drawing.Point(3, 1483);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(75, 28);
            this.label32.TabIndex = 44;
            this.label32.Text = "Flow:";
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label35.Location = new System.Drawing.Point(3, 1561);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(121, 28);
            this.label35.TabIndex = 47;
            this.label35.Text = "Visibility:";
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label34.Location = new System.Drawing.Point(575, 1483);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(186, 28);
            this.label34.TabIndex = 46;
            this.label34.Text = "Obstruction(s):";
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label37.Location = new System.Drawing.Point(3, 1639);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(247, 28);
            this.label37.TabIndex = 49;
            this.label37.Text = "Water Temperature:";
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label33.Location = new System.Drawing.Point(575, 1639);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(206, 28);
            this.label33.TabIndex = 45;
            this.label33.Text = "Other Hazard(s):";
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label36.Location = new System.Drawing.Point(3, 1717);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(165, 28);
            this.label36.TabIndex = 48;
            this.label36.Text = "Water Depth:";
            // 
            // preWaterFlow
            // 
            this.preWaterFlow.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterFlow.Location = new System.Drawing.Point(3, 1513);
            this.preWaterFlow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterFlow.Name = "preWaterFlow";
            this.preWaterFlow.Size = new System.Drawing.Size(544, 34);
            this.preWaterFlow.TabIndex = 50;
            this.preWaterFlow.TextChanged += new System.EventHandler(this.preWaterFlow_TextChanged);
            // 
            // preWaterDepth
            // 
            this.preWaterDepth.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterDepth.Location = new System.Drawing.Point(3, 1747);
            this.preWaterDepth.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterDepth.Name = "preWaterDepth";
            this.preWaterDepth.Size = new System.Drawing.Size(544, 34);
            this.preWaterDepth.TabIndex = 53;
            this.preWaterDepth.TextChanged += new System.EventHandler(this.preWaterDepth_TextChanged);
            // 
            // preWaterTemp
            // 
            this.preWaterTemp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterTemp.Location = new System.Drawing.Point(3, 1669);
            this.preWaterTemp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterTemp.Name = "preWaterTemp";
            this.preWaterTemp.Size = new System.Drawing.Size(544, 34);
            this.preWaterTemp.TabIndex = 52;
            this.preWaterTemp.TextChanged += new System.EventHandler(this.preWaterTemp_TextChanged);
            // 
            // preWaterVisibility
            // 
            this.preWaterVisibility.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterVisibility.Location = new System.Drawing.Point(3, 1591);
            this.preWaterVisibility.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterVisibility.Name = "preWaterVisibility";
            this.preWaterVisibility.Size = new System.Drawing.Size(544, 34);
            this.preWaterVisibility.TabIndex = 51;
            this.preWaterVisibility.TextChanged += new System.EventHandler(this.preWaterVisibility_TextChanged);
            // 
            // preWaterHazards
            // 
            this.preWaterHazards.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterHazards.Location = new System.Drawing.Point(575, 1669);
            this.preWaterHazards.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterHazards.Multiline = true;
            this.preWaterHazards.Name = "preWaterHazards";
            this.preDiveTable.SetRowSpan(this.preWaterHazards, 3);
            this.preWaterHazards.Size = new System.Drawing.Size(544, 112);
            this.preWaterHazards.TabIndex = 54;
            this.preWaterHazards.TextChanged += new System.EventHandler(this.preWaterHazards_TextChanged);
            // 
            // preWaterObstructions
            // 
            this.preWaterObstructions.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preWaterObstructions.Location = new System.Drawing.Point(575, 1513);
            this.preWaterObstructions.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preWaterObstructions.Multiline = true;
            this.preWaterObstructions.Name = "preWaterObstructions";
            this.preDiveTable.SetRowSpan(this.preWaterObstructions, 3);
            this.preWaterObstructions.Size = new System.Drawing.Size(544, 112);
            this.preWaterObstructions.TabIndex = 55;
            this.preWaterObstructions.TextChanged += new System.EventHandler(this.preWaterObstructions_TextChanged);
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label39.Location = new System.Drawing.Point(3, 1815);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(114, 28);
            this.label39.TabIndex = 57;
            this.label39.Text = "Lighting:";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label40.Location = new System.Drawing.Point(575, 1815);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(105, 28);
            this.label40.TabIndex = 58;
            this.label40.Text = "Access:";
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label38.Location = new System.Drawing.Point(3, 1913);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(181, 28);
            this.label38.TabIndex = 56;
            this.label38.Text = "Other Threats:";
            // 
            // preLightning
            // 
            this.preLightning.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preLightning.FormattingEnabled = true;
            this.preLightning.Items.AddRange(new object[] {
            "Daylight",
            "Night",
            "Artificial Light"});
            this.preLightning.Location = new System.Drawing.Point(3, 1845);
            this.preLightning.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preLightning.Name = "preLightning";
            this.preLightning.Size = new System.Drawing.Size(544, 35);
            this.preLightning.TabIndex = 59;
            this.preLightning.SelectedIndexChanged += new System.EventHandler(this.preLightning_SelectedIndexChanged);
            // 
            // preAccess
            // 
            this.preAccess.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preAccess.Location = new System.Drawing.Point(575, 1845);
            this.preAccess.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preAccess.Name = "preAccess";
            this.preAccess.Size = new System.Drawing.Size(544, 34);
            this.preAccess.TabIndex = 60;
            this.preAccess.TextChanged += new System.EventHandler(this.preAccess_TextChanged);
            // 
            // preOtherThreats
            // 
            this.preDiveTable.SetColumnSpan(this.preOtherThreats, 3);
            this.preOtherThreats.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preOtherThreats.Location = new System.Drawing.Point(3, 1943);
            this.preOtherThreats.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preOtherThreats.Multiline = true;
            this.preOtherThreats.Name = "preOtherThreats";
            this.preOtherThreats.Size = new System.Drawing.Size(1117, 34);
            this.preOtherThreats.TabIndex = 61;
            this.preOtherThreats.TextChanged += new System.EventHandler(this.preOtherThreats_TextChanged);
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label41.Location = new System.Drawing.Point(3, 2011);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(266, 28);
            this.label41.TabIndex = 63;
            this.label41.Text = "Operation Objectives:";
            // 
            // preOperationObjectives
            // 
            this.preDiveTable.SetColumnSpan(this.preOperationObjectives, 3);
            this.preOperationObjectives.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preOperationObjectives.Location = new System.Drawing.Point(3, 2041);
            this.preOperationObjectives.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preOperationObjectives.Multiline = true;
            this.preOperationObjectives.Name = "preOperationObjectives";
            this.preOperationObjectives.Size = new System.Drawing.Size(1117, 74);
            this.preOperationObjectives.TabIndex = 64;
            this.preOperationObjectives.TextChanged += new System.EventHandler(this.preOperationObjectives_TextChanged);
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label42.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label42.Location = new System.Drawing.Point(3, 2150);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(241, 28);
            this.label42.TabIndex = 65;
            this.label42.Text = "Personnel Involved:";
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label43.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label43.Location = new System.Drawing.Point(575, 2150);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(224, 28);
            this.label43.TabIndex = 68;
            this.label43.Text = "Vehicles Involved:";
            // 
            // prePersonnelInvolved
            // 
            this.prePersonnelInvolved.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.prePersonnelInvolved.Location = new System.Drawing.Point(3, 2180);
            this.prePersonnelInvolved.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.prePersonnelInvolved.Multiline = true;
            this.prePersonnelInvolved.Name = "prePersonnelInvolved";
            this.prePersonnelInvolved.Size = new System.Drawing.Size(544, 74);
            this.prePersonnelInvolved.TabIndex = 69;
            this.prePersonnelInvolved.TextChanged += new System.EventHandler(this.prePersonnelInvolved_TextChanged);
            // 
            // preVehiclesInvolved
            // 
            this.preVehiclesInvolved.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preVehiclesInvolved.Location = new System.Drawing.Point(575, 2180);
            this.preVehiclesInvolved.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preVehiclesInvolved.Multiline = true;
            this.preVehiclesInvolved.Name = "preVehiclesInvolved";
            this.preVehiclesInvolved.Size = new System.Drawing.Size(544, 74);
            this.preVehiclesInvolved.TabIndex = 70;
            this.preVehiclesInvolved.TextChanged += new System.EventHandler(this.preVehiclesInvolved_TextChanged);
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label44.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label44.Location = new System.Drawing.Point(3, 2289);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(494, 28);
            this.label44.TabIndex = 71;
            this.label44.Text = "Communications/Closest Medical Facility:";
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label45.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label45.Location = new System.Drawing.Point(3, 2328);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(287, 28);
            this.label45.TabIndex = 72;
            this.label45.Text = "Primary Radio Channel:";
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label46.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label46.Location = new System.Drawing.Point(575, 2328);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(319, 28);
            this.label46.TabIndex = 73;
            this.label46.Text = "Secondary Radio Channel:";
            // 
            // prePrimaryRadioChannel
            // 
            this.prePrimaryRadioChannel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.prePrimaryRadioChannel.Location = new System.Drawing.Point(3, 2358);
            this.prePrimaryRadioChannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.prePrimaryRadioChannel.Name = "prePrimaryRadioChannel";
            this.prePrimaryRadioChannel.Size = new System.Drawing.Size(544, 34);
            this.prePrimaryRadioChannel.TabIndex = 74;
            this.prePrimaryRadioChannel.TextChanged += new System.EventHandler(this.prePrimaryRadioChannel_TextChanged);
            // 
            // preSecondaryRadioChannel
            // 
            this.preSecondaryRadioChannel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preSecondaryRadioChannel.Location = new System.Drawing.Point(575, 2358);
            this.preSecondaryRadioChannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSecondaryRadioChannel.Name = "preSecondaryRadioChannel";
            this.preSecondaryRadioChannel.Size = new System.Drawing.Size(545, 34);
            this.preSecondaryRadioChannel.TabIndex = 76;
            this.preSecondaryRadioChannel.TextChanged += new System.EventHandler(this.preSecondaryRadioChannel_TextChanged);
            // 
            // label47
            // 
            this.label47.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label47.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label47.Location = new System.Drawing.Point(3, 2406);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(353, 28);
            this.label47.TabIndex = 77;
            this.label47.Text = "Primary Subsurface Channel:";
            // 
            // prePrimarySubsurfaceChannel
            // 
            this.prePrimarySubsurfaceChannel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.prePrimarySubsurfaceChannel.Location = new System.Drawing.Point(3, 2436);
            this.prePrimarySubsurfaceChannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.prePrimarySubsurfaceChannel.Name = "prePrimarySubsurfaceChannel";
            this.prePrimarySubsurfaceChannel.Size = new System.Drawing.Size(544, 34);
            this.prePrimarySubsurfaceChannel.TabIndex = 78;
            this.prePrimarySubsurfaceChannel.TextChanged += new System.EventHandler(this.prePrimarySubsurfaceChannel_TextChanged);
            // 
            // preSecondarySubsurfaceChannel
            // 
            this.preSecondarySubsurfaceChannel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.preSecondarySubsurfaceChannel.Location = new System.Drawing.Point(575, 2436);
            this.preSecondarySubsurfaceChannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSecondarySubsurfaceChannel.Name = "preSecondarySubsurfaceChannel";
            this.preSecondarySubsurfaceChannel.Size = new System.Drawing.Size(545, 34);
            this.preSecondarySubsurfaceChannel.TabIndex = 79;
            this.preSecondarySubsurfaceChannel.TextChanged += new System.EventHandler(this.preSecondarySubsurfaceChannel_TextChanged);
            // 
            // label48
            // 
            this.label48.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label48.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label48.Location = new System.Drawing.Point(575, 2406);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(385, 28);
            this.label48.TabIndex = 80;
            this.label48.Text = "Secondary Subsurface Channel:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(3, 2504);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 28);
            this.label2.TabIndex = 81;
            this.label2.Text = "Equipment Needed:";
            // 
            // preStandardDiveGear
            // 
            this.preStandardDiveGear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preStandardDiveGear.AutoSize = true;
            this.preStandardDiveGear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preStandardDiveGear.Location = new System.Drawing.Point(3, 2542);
            this.preStandardDiveGear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preStandardDiveGear.Name = "preStandardDiveGear";
            this.preStandardDiveGear.Size = new System.Drawing.Size(225, 27);
            this.preStandardDiveGear.TabIndex = 82;
            this.preStandardDiveGear.Text = "Standard Dive Gear";
            this.preStandardDiveGear.UseVisualStyleBackColor = true;
            this.preStandardDiveGear.CheckedChanged += new System.EventHandler(this.preStandardDiveGear_CheckedChanged);
            // 
            // preSrandardSwiftwaterGear
            // 
            this.preSrandardSwiftwaterGear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preSrandardSwiftwaterGear.AutoSize = true;
            this.preSrandardSwiftwaterGear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preSrandardSwiftwaterGear.Location = new System.Drawing.Point(575, 2503);
            this.preSrandardSwiftwaterGear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preSrandardSwiftwaterGear.Name = "preSrandardSwiftwaterGear";
            this.preSrandardSwiftwaterGear.Size = new System.Drawing.Size(190, 27);
            this.preSrandardSwiftwaterGear.TabIndex = 84;
            this.preSrandardSwiftwaterGear.Text = "Swiftwater Gear";
            this.preSrandardSwiftwaterGear.UseVisualStyleBackColor = true;
            this.preSrandardSwiftwaterGear.CheckedChanged += new System.EventHandler(this.preSrandardSwiftwaterGear_CheckedChanged);
            // 
            // preStandardTenderGear
            // 
            this.preStandardTenderGear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preStandardTenderGear.AutoSize = true;
            this.preStandardTenderGear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preStandardTenderGear.Location = new System.Drawing.Point(3, 2581);
            this.preStandardTenderGear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preStandardTenderGear.Name = "preStandardTenderGear";
            this.preStandardTenderGear.Size = new System.Drawing.Size(253, 27);
            this.preStandardTenderGear.TabIndex = 83;
            this.preStandardTenderGear.Text = "Standard Tender Gear";
            this.preStandardTenderGear.UseVisualStyleBackColor = true;
            this.preStandardTenderGear.CheckedChanged += new System.EventHandler(this.preStandardTenderGear_CheckedChanged);
            // 
            // preStandardIceRescueGear
            // 
            this.preStandardIceRescueGear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preStandardIceRescueGear.AutoSize = true;
            this.preStandardIceRescueGear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preStandardIceRescueGear.Location = new System.Drawing.Point(575, 2542);
            this.preStandardIceRescueGear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preStandardIceRescueGear.Name = "preStandardIceRescueGear";
            this.preStandardIceRescueGear.Size = new System.Drawing.Size(194, 27);
            this.preStandardIceRescueGear.TabIndex = 85;
            this.preStandardIceRescueGear.Text = "Ice Rescue Gear";
            this.preStandardIceRescueGear.UseVisualStyleBackColor = true;
            this.preStandardIceRescueGear.CheckedChanged += new System.EventHandler(this.preStandardIceRescueGear_CheckedChanged);
            // 
            // preOtherGear
            // 
            this.preOtherGear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preOtherGear.AutoSize = true;
            this.preOtherGear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preOtherGear.Location = new System.Drawing.Point(575, 2581);
            this.preOtherGear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preOtherGear.Name = "preOtherGear";
            this.preOtherGear.Size = new System.Drawing.Size(88, 27);
            this.preOtherGear.TabIndex = 86;
            this.preOtherGear.Text = "Other";
            this.preOtherGear.UseVisualStyleBackColor = true;
            this.preOtherGear.CheckedChanged += new System.EventHandler(this.preOtherGear_CheckedChanged);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(3, 2641);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 28);
            this.label3.TabIndex = 87;
            this.label3.Text = "Notifications:";
            // 
            // prePatrolSupervisor
            // 
            this.prePatrolSupervisor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.prePatrolSupervisor.AutoSize = true;
            this.prePatrolSupervisor.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prePatrolSupervisor.Location = new System.Drawing.Point(3, 2679);
            this.prePatrolSupervisor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.prePatrolSupervisor.Name = "prePatrolSupervisor";
            this.prePatrolSupervisor.Size = new System.Drawing.Size(298, 27);
            this.prePatrolSupervisor.TabIndex = 88;
            this.prePatrolSupervisor.Text = "Patrol Sergeant/Supervisor";
            this.prePatrolSupervisor.UseVisualStyleBackColor = true;
            this.prePatrolSupervisor.CheckedChanged += new System.EventHandler(this.prePatrolSupervisor_CheckedChanged);
            // 
            // preAvistaGCC
            // 
            this.preAvistaGCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preAvistaGCC.AutoSize = true;
            this.preAvistaGCC.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preAvistaGCC.Location = new System.Drawing.Point(575, 2640);
            this.preAvistaGCC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preAvistaGCC.Name = "preAvistaGCC";
            this.preAvistaGCC.Size = new System.Drawing.Size(346, 27);
            this.preAvistaGCC.TabIndex = 89;
            this.preAvistaGCC.Text = "Avista GCC - Spokane River Ops";
            this.preAvistaGCC.UseVisualStyleBackColor = true;
            this.preAvistaGCC.CheckedChanged += new System.EventHandler(this.preAvistaGCC_CheckedChanged);
            // 
            // preDispatch
            // 
            this.preDispatch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preDispatch.AutoSize = true;
            this.preDispatch.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preDispatch.Location = new System.Drawing.Point(3, 2718);
            this.preDispatch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preDispatch.Name = "preDispatch";
            this.preDispatch.Size = new System.Drawing.Size(119, 27);
            this.preDispatch.TabIndex = 90;
            this.preDispatch.Text = "Dispatch";
            this.preDispatch.UseVisualStyleBackColor = true;
            this.preDispatch.CheckedChanged += new System.EventHandler(this.preDispatch_CheckedChanged);
            // 
            // preUpriverDam
            // 
            this.preUpriverDam.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preUpriverDam.AutoSize = true;
            this.preUpriverDam.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preUpriverDam.Location = new System.Drawing.Point(575, 2679);
            this.preUpriverDam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preUpriverDam.Name = "preUpriverDam";
            this.preUpriverDam.Size = new System.Drawing.Size(359, 27);
            this.preUpriverDam.TabIndex = 91;
            this.preUpriverDam.Text = "Upriver Dam - Spokane River Ops";
            this.preUpriverDam.UseVisualStyleBackColor = true;
            this.preUpriverDam.CheckedChanged += new System.EventHandler(this.preUpriverDam_CheckedChanged);
            // 
            // preDeaconessHyperbaricChamber
            // 
            this.preDeaconessHyperbaricChamber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preDeaconessHyperbaricChamber.AutoSize = true;
            this.preDeaconessHyperbaricChamber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preDeaconessHyperbaricChamber.Location = new System.Drawing.Point(575, 2718);
            this.preDeaconessHyperbaricChamber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preDeaconessHyperbaricChamber.Name = "preDeaconessHyperbaricChamber";
            this.preDeaconessHyperbaricChamber.Size = new System.Drawing.Size(353, 27);
            this.preDeaconessHyperbaricChamber.TabIndex = 92;
            this.preDeaconessHyperbaricChamber.Text = "Deaconess Hyperbaric Chamber";
            this.preDeaconessHyperbaricChamber.UseVisualStyleBackColor = true;
            this.preDeaconessHyperbaricChamber.CheckedChanged += new System.EventHandler(this.preDeaconessHyperbaricChamber_CheckedChanged);
            // 
            // preShiftCommander
            // 
            this.preShiftCommander.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preShiftCommander.AutoSize = true;
            this.preShiftCommander.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preShiftCommander.Location = new System.Drawing.Point(3, 2757);
            this.preShiftCommander.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preShiftCommander.Name = "preShiftCommander";
            this.preShiftCommander.Size = new System.Drawing.Size(202, 27);
            this.preShiftCommander.TabIndex = 93;
            this.preShiftCommander.Text = "Shift Commander";
            this.preShiftCommander.UseVisualStyleBackColor = true;
            this.preShiftCommander.CheckedChanged += new System.EventHandler(this.preShiftCommander_CheckedChanged);
            // 
            // preOtherNotifications
            // 
            this.preOtherNotifications.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.preOtherNotifications.AutoSize = true;
            this.preOtherNotifications.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preOtherNotifications.Location = new System.Drawing.Point(575, 2757);
            this.preOtherNotifications.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.preOtherNotifications.Name = "preOtherNotifications";
            this.preOtherNotifications.Size = new System.Drawing.Size(88, 27);
            this.preOtherNotifications.TabIndex = 94;
            this.preOtherNotifications.Text = "Other";
            this.preOtherNotifications.UseVisualStyleBackColor = true;
            this.preOtherNotifications.CheckedChanged += new System.EventHandler(this.preOtherNotifications_CheckedChanged);
            // 
            // preDiveLabel
            // 
            this.preDiveLabel.AutoSize = true;
            this.preDiveLabel.BackColor = System.Drawing.Color.DimGray;
            this.preDiveLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preDiveLabel.Location = new System.Drawing.Point(4, 0);
            this.preDiveLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.preDiveLabel.Name = "preDiveLabel";
            this.preDiveLabel.Size = new System.Drawing.Size(156, 39);
            this.preDiveLabel.TabIndex = 3;
            this.preDiveLabel.Text = "Pre Dive";
            // 
            // postDivePanel
            // 
            this.postDivePanel.BackColor = System.Drawing.Color.DimGray;
            this.postDivePanel.Controls.Add(this.postDiveFormPanel);
            this.postDivePanel.Controls.Add(this.postDiveLabel);
            this.postDivePanel.Location = new System.Drawing.Point(168, 34);
            this.postDivePanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.postDivePanel.Name = "postDivePanel";
            this.postDivePanel.Size = new System.Drawing.Size(1160, 849);
            this.postDivePanel.TabIndex = 5;
            this.postDivePanel.Visible = false;
            // 
            // postDiveFormPanel
            // 
            this.postDiveFormPanel.AutoScroll = true;
            this.postDiveFormPanel.BackColor = System.Drawing.Color.Gray;
            this.postDiveFormPanel.Controls.Add(this.debriefTable);
            this.postDiveFormPanel.Location = new System.Drawing.Point(0, 43);
            this.postDiveFormPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.postDiveFormPanel.Name = "postDiveFormPanel";
            this.postDiveFormPanel.Size = new System.Drawing.Size(1160, 806);
            this.postDiveFormPanel.TabIndex = 6;
            // 
            // debriefTable
            // 
            this.debriefTable.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.debriefTable.ColumnCount = 3;
            this.debriefTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.debriefTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.debriefTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.debriefTable.Controls.Add(this.debriefVesselLabel, 0, 2);
            this.debriefTable.Controls.Add(this.debriefVesselText, 0, 3);
            this.debriefTable.Controls.Add(this.debriefDateTimePicker, 2, 0);
            this.debriefTable.Controls.Add(this.debriefEquipmentText, 2, 3);
            this.debriefTable.Controls.Add(this.debriefDateTimeLabel, 0, 0);
            this.debriefTable.Controls.Add(this.debriefEquipmentLabel, 2, 2);
            this.debriefTable.Controls.Add(this.debriefInjuriesLabel, 0, 5);
            this.debriefTable.Controls.Add(this.debriefInjuriesText, 0, 6);
            this.debriefTable.Controls.Add(this.debriefPropertyText, 2, 6);
            this.debriefTable.Controls.Add(this.debriefPropertyLabel, 2, 5);
            this.debriefTable.Controls.Add(this.debriefPropertySupervisorLabel, 2, 7);
            this.debriefTable.Controls.Add(this.debriefPropertySupervisorCombo, 2, 8);
            this.debriefTable.Controls.Add(this.debriefInjuriesSupervisorCombo, 0, 8);
            this.debriefTable.Controls.Add(this.debriefInjuriesSupervisorLabel, 0, 7);
            this.debriefTable.Controls.Add(this.debriefWorkedWellLabel, 0, 9);
            this.debriefTable.Controls.Add(this.debriefNotWorkedWellLabel, 2, 9);
            this.debriefTable.Controls.Add(this.debriefWorkedWellText, 0, 10);
            this.debriefTable.Controls.Add(this.debriefNotWorkedWellText, 2, 10);
            this.debriefTable.Location = new System.Drawing.Point(12, 20);
            this.debriefTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefTable.Name = "debriefTable";
            this.debriefTable.RowCount = 12;
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.debriefTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.debriefTable.Size = new System.Drawing.Size(1125, 729);
            this.debriefTable.TabIndex = 57;
            // 
            // debriefVesselLabel
            // 
            this.debriefVesselLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefVesselLabel.AutoSize = true;
            this.debriefVesselLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefVesselLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefVesselLabel.Location = new System.Drawing.Point(3, 69);
            this.debriefVesselLabel.Name = "debriefVesselLabel";
            this.debriefVesselLabel.Size = new System.Drawing.Size(382, 28);
            this.debriefVesselLabel.TabIndex = 3;
            this.debriefVesselLabel.Text = "Did any vessel problems occur?";
            // 
            // debriefVesselText
            // 
            this.debriefVesselText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefVesselText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefVesselText.Location = new System.Drawing.Point(3, 99);
            this.debriefVesselText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefVesselText.Multiline = true;
            this.debriefVesselText.Name = "debriefVesselText";
            this.debriefVesselText.Size = new System.Drawing.Size(544, 94);
            this.debriefVesselText.TabIndex = 2;
            this.debriefVesselText.TextChanged += new System.EventHandler(this.debriefVesselText_TextChanged);
            // 
            // debriefDateTimePicker
            // 
            this.debriefDateTimePicker.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.debriefDateTimePicker.CalendarTitleForeColor = System.Drawing.SystemColors.Control;
            this.debriefDateTimePicker.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16F);
            this.debriefDateTimePicker.Location = new System.Drawing.Point(576, 2);
            this.debriefDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefDateTimePicker.Name = "debriefDateTimePicker";
            this.debriefDateTimePicker.Size = new System.Drawing.Size(545, 38);
            this.debriefDateTimePicker.TabIndex = 56;
            this.debriefDateTimePicker.ValueChanged += new System.EventHandler(this.debriefDateTimePicker_ValueChanged);
            // 
            // debriefEquipmentText
            // 
            this.debriefEquipmentText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefEquipmentText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefEquipmentText.Location = new System.Drawing.Point(576, 99);
            this.debriefEquipmentText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefEquipmentText.Multiline = true;
            this.debriefEquipmentText.Name = "debriefEquipmentText";
            this.debriefEquipmentText.Size = new System.Drawing.Size(545, 94);
            this.debriefEquipmentText.TabIndex = 4;
            this.debriefEquipmentText.TextChanged += new System.EventHandler(this.debriefEquipmentText_TextChanged);
            // 
            // debriefDateTimeLabel
            // 
            this.debriefDateTimeLabel.AutoSize = true;
            this.debriefDateTimeLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefDateTimeLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefDateTimeLabel.Location = new System.Drawing.Point(4, 0);
            this.debriefDateTimeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.debriefDateTimeLabel.Name = "debriefDateTimeLabel";
            this.debriefDateTimeLabel.Size = new System.Drawing.Size(157, 32);
            this.debriefDateTimeLabel.TabIndex = 6;
            this.debriefDateTimeLabel.Text = "Date/Time:";
            // 
            // debriefEquipmentLabel
            // 
            this.debriefEquipmentLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefEquipmentLabel.AutoSize = true;
            this.debriefEquipmentLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefEquipmentLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefEquipmentLabel.Location = new System.Drawing.Point(576, 69);
            this.debriefEquipmentLabel.Name = "debriefEquipmentLabel";
            this.debriefEquipmentLabel.Size = new System.Drawing.Size(430, 28);
            this.debriefEquipmentLabel.TabIndex = 5;
            this.debriefEquipmentLabel.Text = "Did any equipment problems occur?";
            // 
            // debriefInjuriesLabel
            // 
            this.debriefInjuriesLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefInjuriesLabel.AutoSize = true;
            this.debriefInjuriesLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefInjuriesLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefInjuriesLabel.Location = new System.Drawing.Point(3, 234);
            this.debriefInjuriesLabel.Name = "debriefInjuriesLabel";
            this.debriefInjuriesLabel.Size = new System.Drawing.Size(295, 28);
            this.debriefInjuriesLabel.TabIndex = 6;
            this.debriefInjuriesLabel.Text = "Were there any injuries?";
            // 
            // debriefInjuriesText
            // 
            this.debriefInjuriesText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefInjuriesText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefInjuriesText.Location = new System.Drawing.Point(3, 264);
            this.debriefInjuriesText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefInjuriesText.Multiline = true;
            this.debriefInjuriesText.Name = "debriefInjuriesText";
            this.debriefInjuriesText.Size = new System.Drawing.Size(544, 94);
            this.debriefInjuriesText.TabIndex = 7;
            this.debriefInjuriesText.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // debriefPropertyText
            // 
            this.debriefPropertyText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefPropertyText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefPropertyText.Location = new System.Drawing.Point(576, 264);
            this.debriefPropertyText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefPropertyText.Multiline = true;
            this.debriefPropertyText.Name = "debriefPropertyText";
            this.debriefPropertyText.Size = new System.Drawing.Size(545, 94);
            this.debriefPropertyText.TabIndex = 10;
            this.debriefPropertyText.TextChanged += new System.EventHandler(this.debriefPropertyText_TextChanged);
            // 
            // debriefPropertyLabel
            // 
            this.debriefPropertyLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefPropertyLabel.AutoSize = true;
            this.debriefPropertyLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefPropertyLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefPropertyLabel.Location = new System.Drawing.Point(576, 234);
            this.debriefPropertyLabel.Name = "debriefPropertyLabel";
            this.debriefPropertyLabel.Size = new System.Drawing.Size(490, 28);
            this.debriefPropertyLabel.TabIndex = 9;
            this.debriefPropertyLabel.Text = "Was there any lost or damaged property?";
            // 
            // debriefPropertySupervisorLabel
            // 
            this.debriefPropertySupervisorLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefPropertySupervisorLabel.AutoSize = true;
            this.debriefPropertySupervisorLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefPropertySupervisorLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefPropertySupervisorLabel.Location = new System.Drawing.Point(576, 371);
            this.debriefPropertySupervisorLabel.Name = "debriefPropertySupervisorLabel";
            this.debriefPropertySupervisorLabel.Size = new System.Drawing.Size(394, 56);
            this.debriefPropertySupervisorLabel.TabIndex = 12;
            this.debriefPropertySupervisorLabel.Text = "Did the supervisor complete the administrative packet(property)?";
            // 
            // debriefPropertySupervisorCombo
            // 
            this.debriefPropertySupervisorCombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefPropertySupervisorCombo.FormattingEnabled = true;
            this.debriefPropertySupervisorCombo.Location = new System.Drawing.Point(576, 429);
            this.debriefPropertySupervisorCombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefPropertySupervisorCombo.Name = "debriefPropertySupervisorCombo";
            this.debriefPropertySupervisorCombo.Size = new System.Drawing.Size(545, 40);
            this.debriefPropertySupervisorCombo.TabIndex = 13;
            this.debriefPropertySupervisorCombo.SelectedIndexChanged += new System.EventHandler(this.debriefPropertySupervisorCombo_SelectedIndexChanged);
            // 
            // debriefInjuriesSupervisorCombo
            // 
            this.debriefInjuriesSupervisorCombo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefInjuriesSupervisorCombo.FormattingEnabled = true;
            this.debriefInjuriesSupervisorCombo.Location = new System.Drawing.Point(3, 429);
            this.debriefInjuriesSupervisorCombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefInjuriesSupervisorCombo.Name = "debriefInjuriesSupervisorCombo";
            this.debriefInjuriesSupervisorCombo.Size = new System.Drawing.Size(543, 40);
            this.debriefInjuriesSupervisorCombo.TabIndex = 11;
            this.debriefInjuriesSupervisorCombo.SelectedIndexChanged += new System.EventHandler(this.debriefInjuriesSupervisorCombo_SelectedIndexChanged);
            // 
            // debriefInjuriesSupervisorLabel
            // 
            this.debriefInjuriesSupervisorLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefInjuriesSupervisorLabel.AutoSize = true;
            this.debriefInjuriesSupervisorLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefInjuriesSupervisorLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefInjuriesSupervisorLabel.Location = new System.Drawing.Point(3, 371);
            this.debriefInjuriesSupervisorLabel.Name = "debriefInjuriesSupervisorLabel";
            this.debriefInjuriesSupervisorLabel.Size = new System.Drawing.Size(386, 56);
            this.debriefInjuriesSupervisorLabel.TabIndex = 8;
            this.debriefInjuriesSupervisorLabel.Text = "Did the supervisor complete the administrative packet(injuries)?";
            // 
            // debriefWorkedWellLabel
            // 
            this.debriefWorkedWellLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefWorkedWellLabel.AutoSize = true;
            this.debriefWorkedWellLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefWorkedWellLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefWorkedWellLabel.Location = new System.Drawing.Point(3, 498);
            this.debriefWorkedWellLabel.Name = "debriefWorkedWellLabel";
            this.debriefWorkedWellLabel.Size = new System.Drawing.Size(233, 28);
            this.debriefWorkedWellLabel.TabIndex = 16;
            this.debriefWorkedWellLabel.Text = "What worked well?";
            // 
            // debriefNotWorkedWellLabel
            // 
            this.debriefNotWorkedWellLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.debriefNotWorkedWellLabel.AutoSize = true;
            this.debriefNotWorkedWellLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debriefNotWorkedWellLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.debriefNotWorkedWellLabel.Location = new System.Drawing.Point(576, 498);
            this.debriefNotWorkedWellLabel.Name = "debriefNotWorkedWellLabel";
            this.debriefNotWorkedWellLabel.Size = new System.Drawing.Size(275, 28);
            this.debriefNotWorkedWellLabel.TabIndex = 17;
            this.debriefNotWorkedWellLabel.Text = "What didn\'t work well?";
            // 
            // debriefWorkedWellText
            // 
            this.debriefWorkedWellText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefWorkedWellText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefWorkedWellText.Location = new System.Drawing.Point(3, 529);
            this.debriefWorkedWellText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefWorkedWellText.Multiline = true;
            this.debriefWorkedWellText.Name = "debriefWorkedWellText";
            this.debriefWorkedWellText.Size = new System.Drawing.Size(544, 127);
            this.debriefWorkedWellText.TabIndex = 14;
            this.debriefWorkedWellText.TextChanged += new System.EventHandler(this.debriefWorkedWellText_TextChanged);
            // 
            // debriefNotWorkedWellText
            // 
            this.debriefNotWorkedWellText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.debriefNotWorkedWellText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F);
            this.debriefNotWorkedWellText.Location = new System.Drawing.Point(576, 529);
            this.debriefNotWorkedWellText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.debriefNotWorkedWellText.Multiline = true;
            this.debriefNotWorkedWellText.Name = "debriefNotWorkedWellText";
            this.debriefNotWorkedWellText.Size = new System.Drawing.Size(545, 127);
            this.debriefNotWorkedWellText.TabIndex = 15;
            this.debriefNotWorkedWellText.TextChanged += new System.EventHandler(this.debriefNotWorkedWellText_TextChanged);
            // 
            // postDiveLabel
            // 
            this.postDiveLabel.AutoSize = true;
            this.postDiveLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postDiveLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.postDiveLabel.Location = new System.Drawing.Point(4, 0);
            this.postDiveLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.postDiveLabel.Name = "postDiveLabel";
            this.postDiveLabel.Size = new System.Drawing.Size(172, 39);
            this.postDiveLabel.TabIndex = 5;
            this.postDiveLabel.Text = "Post Dive";
            // 
            // activeDivePanel
            // 
            this.activeDivePanel.BackColor = System.Drawing.Color.DimGray;
            this.activeDivePanel.Controls.Add(this.tabControl1);
            this.activeDivePanel.Controls.Add(this.label1);
            this.activeDivePanel.Location = new System.Drawing.Point(168, 34);
            this.activeDivePanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.activeDivePanel.Name = "activeDivePanel";
            this.activeDivePanel.Size = new System.Drawing.Size(1160, 849);
            this.activeDivePanel.TabIndex = 5;
            this.activeDivePanel.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 43);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1155, 802);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.Gray;
            this.tabPage1.Controls.Add(this.activeDiveTable);
            this.tabPage1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage1.Location = new System.Drawing.Point(4, 36);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1147, 762);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Active Divers";
            // 
            // activeDiveTable
            // 
            this.activeDiveTable.BackColor = System.Drawing.Color.DimGray;
            this.activeDiveTable.ColumnCount = 5;
            this.activeDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.99309F));
            this.activeDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.5103619F));
            this.activeDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.99309F));
            this.activeDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.5103619F));
            this.activeDiveTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.99309F));
            this.activeDiveTable.Controls.Add(this.panel5, 4, 1);
            this.activeDiveTable.Controls.Add(this.panel2, 2, 1);
            this.activeDiveTable.Controls.Add(this.label49, 0, 0);
            this.activeDiveTable.Controls.Add(this.label50, 2, 0);
            this.activeDiveTable.Controls.Add(this.label51, 4, 0);
            this.activeDiveTable.Controls.Add(this.panel4, 0, 1);
            this.activeDiveTable.Location = new System.Drawing.Point(3, 5);
            this.activeDiveTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.activeDiveTable.Name = "activeDiveTable";
            this.activeDiveTable.RowCount = 2;
            this.activeDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.activeDiveTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.activeDiveTable.Size = new System.Drawing.Size(1113, 1453);
            this.activeDiveTable.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gray;
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.textBox45);
            this.panel5.Controls.Add(this.label71);
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.label72);
            this.panel5.Controls.Add(this.comboBox12);
            this.panel5.Controls.Add(this.label73);
            this.panel5.Controls.Add(this.comboBox13);
            this.panel5.Controls.Add(this.label74);
            this.panel5.Controls.Add(this.comboBox14);
            this.panel5.Controls.Add(this.label75);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(747, 41);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(363, 1463);
            this.panel5.TabIndex = 9;
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(7, 377);
            this.textBox45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox45.Multiline = true;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(340, 95);
            this.textBox45.TabIndex = 10;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(1, 338);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(179, 28);
            this.label71.TabIndex = 9;
            this.label71.Text = "Mission Roles:";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DimGray;
            this.button6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(165, 292);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 34);
            this.button6.TabIndex = 8;
            this.button6.Text = "No";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DimGray;
            this.button7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(69, 292);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(89, 34);
            this.button7.TabIndex = 7;
            this.button7.Text = "Yes";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(4, 261);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(334, 28);
            this.label72.TabIndex = 6;
            this.label72.Text = "Need a Rapid Neuro check?";
            // 
            // comboBox12
            // 
            this.comboBox12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(7, 209);
            this.comboBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(340, 35);
            this.comboBox12.TabIndex = 5;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(3, 170);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(283, 28);
            this.label73.TabIndex = 4;
            this.label73.Text = "Equipment checked by:";
            // 
            // comboBox13
            // 
            this.comboBox13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(5, 121);
            this.comboBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(340, 35);
            this.comboBox13.TabIndex = 3;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(0, 90);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(103, 28);
            this.label74.TabIndex = 2;
            this.label74.Text = "Tender:";
            // 
            // comboBox14
            // 
            this.comboBox14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(7, 46);
            this.comboBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(340, 35);
            this.comboBox14.TabIndex = 1;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(1, 15);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(87, 28);
            this.label75.TabIndex = 0;
            this.label75.Text = "Name:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.textBox42);
            this.panel2.Controls.Add(this.label63);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.label64);
            this.panel2.Controls.Add(this.comboBox9);
            this.panel2.Controls.Add(this.label65);
            this.panel2.Controls.Add(this.comboBox10);
            this.panel2.Controls.Add(this.label66);
            this.panel2.Controls.Add(this.comboBox11);
            this.panel2.Controls.Add(this.label67);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(375, 41);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(361, 1463);
            this.panel2.TabIndex = 9;
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(7, 377);
            this.textBox42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox42.Multiline = true;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(340, 95);
            this.textBox42.TabIndex = 10;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(1, 338);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(179, 28);
            this.label63.TabIndex = 9;
            this.label63.Text = "Mission Roles:";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DimGray;
            this.button4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(165, 292);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 34);
            this.button4.TabIndex = 8;
            this.button4.Text = "No";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DimGray;
            this.button5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(69, 292);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 34);
            this.button5.TabIndex = 7;
            this.button5.Text = "Yes";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(4, 261);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(334, 28);
            this.label64.TabIndex = 6;
            this.label64.Text = "Need a Rapid Neuro check?";
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(7, 209);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(340, 35);
            this.comboBox9.TabIndex = 5;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(3, 170);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(283, 28);
            this.label65.TabIndex = 4;
            this.label65.Text = "Equipment checked by:";
            // 
            // comboBox10
            // 
            this.comboBox10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(5, 121);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(340, 35);
            this.comboBox10.TabIndex = 3;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(0, 90);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(103, 28);
            this.label66.TabIndex = 2;
            this.label66.Text = "Tender:";
            // 
            // comboBox11
            // 
            this.comboBox11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(7, 46);
            this.comboBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(340, 35);
            this.comboBox11.TabIndex = 1;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(1, 15);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(87, 28);
            this.label67.TabIndex = 0;
            this.label67.Text = "Name:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label49.Location = new System.Drawing.Point(4, 0);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(243, 39);
            this.label49.TabIndex = 5;
            this.label49.Text = "Primary Diver";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label50.Location = new System.Drawing.Point(376, 0);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(217, 39);
            this.label50.TabIndex = 6;
            this.label50.Text = "Safety Diver";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label51.Location = new System.Drawing.Point(748, 0);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(182, 39);
            this.label51.TabIndex = 7;
            this.label51.Text = "90% Diver";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.textBox37);
            this.panel4.Controls.Add(this.label56);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.label55);
            this.panel4.Controls.Add(this.comboBox8);
            this.panel4.Controls.Add(this.label54);
            this.panel4.Controls.Add(this.comboBox7);
            this.panel4.Controls.Add(this.label53);
            this.panel4.Controls.Add(this.comboBox6);
            this.panel4.Controls.Add(this.label52);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 41);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(361, 1463);
            this.panel4.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Controls.Add(this.textBox10);
            this.panel7.Controls.Add(this.textBox9);
            this.panel7.Controls.Add(this.label135);
            this.panel7.Controls.Add(this.textBox8);
            this.panel7.Controls.Add(this.textBox7);
            this.panel7.Controls.Add(this.label134);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.textBox4);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.textBox3);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.maskedTextBox4);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.textBox2);
            this.panel7.Controls.Add(this.textBox1);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.textBox39);
            this.panel7.Controls.Add(this.label59);
            this.panel7.Controls.Add(this.textBox38);
            this.panel7.Controls.Add(this.label58);
            this.panel7.Controls.Add(this.label57);
            this.panel7.Location = new System.Drawing.Point(1, 506);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(363, 889);
            this.panel7.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(62, 807);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 43);
            this.button1.TabIndex = 23;
            this.button1.Text = "New Segment";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(6, 654);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(338, 136);
            this.textBox4.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(4, 620);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(309, 28);
            this.label7.TabIndex = 21;
            this.label7.Text = "Dive Segment Comments:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(5, 573);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(340, 34);
            this.textBox3.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 537);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 28);
            this.label6.TabIndex = 19;
            this.label6.Text = "Depth:";
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(8, 487);
            this.maskedTextBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maskedTextBox4.Mask = "00:00";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(336, 39);
            this.maskedTextBox4.TabIndex = 18;
            this.maskedTextBox4.ValidatingType = typeof(System.DateTime);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 450);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(331, 28);
            this.label5.TabIndex = 17;
            this.label5.Text = "Time Out of Water(Military):";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(184, 244);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(160, 34);
            this.textBox2.TabIndex = 16;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(7, 244);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 34);
            this.textBox1.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(281, 28);
            this.label4.TabIndex = 14;
            this.label4.Text = "Air Check 1 (Time/PSI):";
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(7, 162);
            this.textBox39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(340, 34);
            this.textBox39.TabIndex = 13;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(3, 128);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(180, 28);
            this.label59.TabIndex = 12;
            this.label59.Text = "Time in Water:";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(7, 85);
            this.textBox38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(340, 34);
            this.textBox38.TabIndex = 11;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(3, 50);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(200, 28);
            this.label58.TabIndex = 10;
            this.label58.Text = "Starting Air PSI:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label57.Location = new System.Drawing.Point(3, 0);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(245, 39);
            this.label57.TabIndex = 7;
            this.label57.Text = "Dive Segment";
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(7, 377);
            this.textBox37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox37.Multiline = true;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(340, 95);
            this.textBox37.TabIndex = 10;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(1, 338);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(179, 28);
            this.label56.TabIndex = 9;
            this.label56.Text = "Mission Roles:";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DimGray;
            this.button3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(165, 292);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(89, 34);
            this.button3.TabIndex = 8;
            this.button3.Text = "No";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DimGray;
            this.button2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(69, 292);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 34);
            this.button2.TabIndex = 7;
            this.button2.Text = "Yes";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(4, 261);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(334, 28);
            this.label55.TabIndex = 6;
            this.label55.Text = "Need a Rapid Neuro check?";
            // 
            // comboBox8
            // 
            this.comboBox8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(7, 209);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(340, 35);
            this.comboBox8.TabIndex = 5;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(3, 170);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(283, 28);
            this.label54.TabIndex = 4;
            this.label54.Text = "Equipment checked by:";
            // 
            // comboBox7
            // 
            this.comboBox7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(5, 121);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(340, 35);
            this.comboBox7.TabIndex = 3;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(0, 90);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(103, 28);
            this.label53.TabIndex = 2;
            this.label53.Text = "Tender:";
            // 
            // comboBox6
            // 
            this.comboBox6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(7, 46);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(340, 35);
            this.comboBox6.TabIndex = 1;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(1, 15);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(87, 28);
            this.label52.TabIndex = 0;
            this.label52.Text = "Name:";
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.Gray;
            this.tabPage2.Controls.Add(this.tableLayoutPanel1);
            this.tabPage2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage2.Location = new System.Drawing.Point(4, 36);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1147, 762);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Rapid Neuros";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Controls.Add(this.label80, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label81, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label82, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label83, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label84, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label85, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.label86, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.label87, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.label88, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.label89, 0, 17);
            this.tableLayoutPanel1.Controls.Add(this.label90, 0, 18);
            this.tableLayoutPanel1.Controls.Add(this.label91, 0, 19);
            this.tableLayoutPanel1.Controls.Add(this.label92, 0, 21);
            this.tableLayoutPanel1.Controls.Add(this.label93, 0, 22);
            this.tableLayoutPanel1.Controls.Add(this.label94, 0, 23);
            this.tableLayoutPanel1.Controls.Add(this.label95, 0, 24);
            this.tableLayoutPanel1.Controls.Add(this.label96, 0, 25);
            this.tableLayoutPanel1.Controls.Add(this.label97, 0, 28);
            this.tableLayoutPanel1.Controls.Add(this.label98, 0, 29);
            this.tableLayoutPanel1.Controls.Add(this.label99, 0, 30);
            this.tableLayoutPanel1.Controls.Add(this.label100, 0, 33);
            this.tableLayoutPanel1.Controls.Add(this.label101, 0, 34);
            this.tableLayoutPanel1.Controls.Add(this.label102, 0, 27);
            this.tableLayoutPanel1.Controls.Add(this.label103, 0, 32);
            this.tableLayoutPanel1.Controls.Add(this.label104, 0, 36);
            this.tableLayoutPanel1.Controls.Add(this.label105, 0, 37);
            this.tableLayoutPanel1.Controls.Add(this.label106, 0, 38);
            this.tableLayoutPanel1.Controls.Add(this.label107, 0, 39);
            this.tableLayoutPanel1.Controls.Add(this.label108, 0, 40);
            this.tableLayoutPanel1.Controls.Add(this.label109, 0, 41);
            this.tableLayoutPanel1.Controls.Add(this.label110, 0, 42);
            this.tableLayoutPanel1.Controls.Add(this.label111, 0, 43);
            this.tableLayoutPanel1.Controls.Add(this.label112, 0, 44);
            this.tableLayoutPanel1.Controls.Add(this.label113, 0, 45);
            this.tableLayoutPanel1.Controls.Add(this.label114, 0, 46);
            this.tableLayoutPanel1.Controls.Add(this.label115, 0, 47);
            this.tableLayoutPanel1.Controls.Add(this.label116, 0, 49);
            this.tableLayoutPanel1.Controls.Add(this.label117, 0, 55);
            this.tableLayoutPanel1.Controls.Add(this.label118, 0, 60);
            this.tableLayoutPanel1.Controls.Add(this.label120, 0, 50);
            this.tableLayoutPanel1.Controls.Add(this.label119, 0, 51);
            this.tableLayoutPanel1.Controls.Add(this.label121, 0, 52);
            this.tableLayoutPanel1.Controls.Add(this.label122, 0, 53);
            this.tableLayoutPanel1.Controls.Add(this.label123, 0, 56);
            this.tableLayoutPanel1.Controls.Add(this.label124, 0, 57);
            this.tableLayoutPanel1.Controls.Add(this.label125, 0, 58);
            this.tableLayoutPanel1.Controls.Add(this.label126, 0, 61);
            this.tableLayoutPanel1.Controls.Add(this.label127, 0, 62);
            this.tableLayoutPanel1.Controls.Add(this.label128, 0, 63);
            this.tableLayoutPanel1.Controls.Add(this.label129, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label131, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label132, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label130, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox52, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox53, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker2, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.radioButton13, 2, 63);
            this.tableLayoutPanel1.Controls.Add(this.radioButton3, 2, 62);
            this.tableLayoutPanel1.Controls.Add(this.radioButton15, 2, 61);
            this.tableLayoutPanel1.Controls.Add(this.radioButton14, 2, 58);
            this.tableLayoutPanel1.Controls.Add(this.radioButton16, 2, 57);
            this.tableLayoutPanel1.Controls.Add(this.radioButton25, 2, 56);
            this.tableLayoutPanel1.Controls.Add(this.radioButton2, 2, 50);
            this.tableLayoutPanel1.Controls.Add(this.radioButton4, 2, 51);
            this.tableLayoutPanel1.Controls.Add(this.radioButton1, 2, 52);
            this.tableLayoutPanel1.Controls.Add(this.radioButton17, 2, 53);
            this.tableLayoutPanel1.Controls.Add(this.radioButton24, 2, 47);
            this.tableLayoutPanel1.Controls.Add(this.radioButton7, 2, 46);
            this.tableLayoutPanel1.Controls.Add(this.radioButton22, 2, 45);
            this.tableLayoutPanel1.Controls.Add(this.radioButton27, 2, 44);
            this.tableLayoutPanel1.Controls.Add(this.radioButton29, 2, 43);
            this.tableLayoutPanel1.Controls.Add(this.radioButton26, 2, 42);
            this.tableLayoutPanel1.Controls.Add(this.radioButton20, 2, 41);
            this.tableLayoutPanel1.Controls.Add(this.radioButton28, 2, 40);
            this.tableLayoutPanel1.Controls.Add(this.radioButton30, 2, 39);
            this.tableLayoutPanel1.Controls.Add(this.radioButton23, 2, 38);
            this.tableLayoutPanel1.Controls.Add(this.radioButton21, 2, 37);
            this.tableLayoutPanel1.Controls.Add(this.radioButton18, 2, 34);
            this.tableLayoutPanel1.Controls.Add(this.radioButton19, 2, 33);
            this.tableLayoutPanel1.Controls.Add(this.radioButton5, 2, 30);
            this.tableLayoutPanel1.Controls.Add(this.radioButton6, 2, 29);
            this.tableLayoutPanel1.Controls.Add(this.radioButton8, 2, 28);
            this.tableLayoutPanel1.Controls.Add(this.radioButton9, 2, 25);
            this.tableLayoutPanel1.Controls.Add(this.radioButton10, 2, 24);
            this.tableLayoutPanel1.Controls.Add(this.radioButton11, 2, 23);
            this.tableLayoutPanel1.Controls.Add(this.radioButton12, 2, 22);
            this.tableLayoutPanel1.Controls.Add(this.radioButton35, 2, 18);
            this.tableLayoutPanel1.Controls.Add(this.radioButton34, 2, 15);
            this.tableLayoutPanel1.Controls.Add(this.radioButton33, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.radioButton32, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.radioButton31, 2, 19);
            this.tableLayoutPanel1.Controls.Add(this.radioButton39, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.radioButton38, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.radioButton37, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.radioButton36, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.radioButton40, 4, 62);
            this.tableLayoutPanel1.Controls.Add(this.radioButton47, 4, 61);
            this.tableLayoutPanel1.Controls.Add(this.radioButton46, 4, 63);
            this.tableLayoutPanel1.Controls.Add(this.radioButton41, 4, 58);
            this.tableLayoutPanel1.Controls.Add(this.radioButton44, 4, 56);
            this.tableLayoutPanel1.Controls.Add(this.radioButton45, 4, 57);
            this.tableLayoutPanel1.Controls.Add(this.radioButton42, 4, 53);
            this.tableLayoutPanel1.Controls.Add(this.radioButton43, 4, 52);
            this.tableLayoutPanel1.Controls.Add(this.radioButton50, 4, 43);
            this.tableLayoutPanel1.Controls.Add(this.radioButton49, 4, 44);
            this.tableLayoutPanel1.Controls.Add(this.radioButton52, 4, 45);
            this.tableLayoutPanel1.Controls.Add(this.radioButton53, 4, 46);
            this.tableLayoutPanel1.Controls.Add(this.radioButton48, 4, 51);
            this.tableLayoutPanel1.Controls.Add(this.radioButton54, 4, 50);
            this.tableLayoutPanel1.Controls.Add(this.radioButton51, 4, 47);
            this.tableLayoutPanel1.Controls.Add(this.radioButton55, 4, 42);
            this.tableLayoutPanel1.Controls.Add(this.radioButton61, 4, 41);
            this.tableLayoutPanel1.Controls.Add(this.radioButton56, 4, 40);
            this.tableLayoutPanel1.Controls.Add(this.radioButton57, 4, 39);
            this.tableLayoutPanel1.Controls.Add(this.radioButton58, 4, 38);
            this.tableLayoutPanel1.Controls.Add(this.radioButton59, 4, 37);
            this.tableLayoutPanel1.Controls.Add(this.radioButton60, 4, 34);
            this.tableLayoutPanel1.Controls.Add(this.radioButton62, 4, 29);
            this.tableLayoutPanel1.Controls.Add(this.radioButton63, 4, 28);
            this.tableLayoutPanel1.Controls.Add(this.radioButton65, 4, 33);
            this.tableLayoutPanel1.Controls.Add(this.radioButton64, 4, 30);
            this.tableLayoutPanel1.Controls.Add(this.radioButton66, 4, 25);
            this.tableLayoutPanel1.Controls.Add(this.radioButton67, 4, 24);
            this.tableLayoutPanel1.Controls.Add(this.radioButton68, 4, 23);
            this.tableLayoutPanel1.Controls.Add(this.radioButton75, 4, 19);
            this.tableLayoutPanel1.Controls.Add(this.radioButton74, 4, 18);
            this.tableLayoutPanel1.Controls.Add(this.radioButton73, 4, 15);
            this.tableLayoutPanel1.Controls.Add(this.radioButton72, 4, 14);
            this.tableLayoutPanel1.Controls.Add(this.radioButton71, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.radioButton70, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.radioButton69, 4, 22);
            this.tableLayoutPanel1.Controls.Add(this.radioButton78, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.radioButton77, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.radioButton76, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.label133, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox56, 6, 63);
            this.tableLayoutPanel1.Controls.Add(this.textBox55, 6, 62);
            this.tableLayoutPanel1.Controls.Add(this.textBox59, 6, 61);
            this.tableLayoutPanel1.Controls.Add(this.textBox54, 6, 58);
            this.tableLayoutPanel1.Controls.Add(this.textBox60, 6, 57);
            this.tableLayoutPanel1.Controls.Add(this.textBox61, 6, 56);
            this.tableLayoutPanel1.Controls.Add(this.textBox62, 6, 53);
            this.tableLayoutPanel1.Controls.Add(this.textBox58, 6, 52);
            this.tableLayoutPanel1.Controls.Add(this.textBox57, 6, 51);
            this.tableLayoutPanel1.Controls.Add(this.textBox69, 6, 50);
            this.tableLayoutPanel1.Controls.Add(this.textBox66, 6, 47);
            this.tableLayoutPanel1.Controls.Add(this.textBox68, 6, 46);
            this.tableLayoutPanel1.Controls.Add(this.textBox67, 6, 45);
            this.tableLayoutPanel1.Controls.Add(this.textBox64, 6, 44);
            this.tableLayoutPanel1.Controls.Add(this.textBox65, 6, 43);
            this.tableLayoutPanel1.Controls.Add(this.textBox63, 6, 42);
            this.tableLayoutPanel1.Controls.Add(this.textBox70, 6, 41);
            this.tableLayoutPanel1.Controls.Add(this.textBox72, 6, 40);
            this.tableLayoutPanel1.Controls.Add(this.textBox73, 6, 39);
            this.tableLayoutPanel1.Controls.Add(this.textBox74, 6, 38);
            this.tableLayoutPanel1.Controls.Add(this.textBox76, 6, 37);
            this.tableLayoutPanel1.Controls.Add(this.textBox75, 6, 34);
            this.tableLayoutPanel1.Controls.Add(this.textBox71, 6, 33);
            this.tableLayoutPanel1.Controls.Add(this.textBox77, 6, 29);
            this.tableLayoutPanel1.Controls.Add(this.textBox78, 6, 28);
            this.tableLayoutPanel1.Controls.Add(this.textBox79, 6, 30);
            this.tableLayoutPanel1.Controls.Add(this.textBox82, 6, 25);
            this.tableLayoutPanel1.Controls.Add(this.textBox80, 6, 24);
            this.tableLayoutPanel1.Controls.Add(this.textBox81, 6, 23);
            this.tableLayoutPanel1.Controls.Add(this.textBox83, 6, 22);
            this.tableLayoutPanel1.Controls.Add(this.textBox90, 6, 18);
            this.tableLayoutPanel1.Controls.Add(this.textBox89, 6, 19);
            this.tableLayoutPanel1.Controls.Add(this.textBox88, 6, 15);
            this.tableLayoutPanel1.Controls.Add(this.textBox87, 6, 14);
            this.tableLayoutPanel1.Controls.Add(this.textBox86, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.textBox85, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBox84, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBox92, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBox91, 6, 7);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 2);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 65;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1117, 2377);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label80
            // 
            this.label80.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(3, 203);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(211, 32);
            this.label80.TabIndex = 0;
            this.label80.Text = "Mental Status:";
            // 
            // label81
            // 
            this.label81.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(3, 246);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(156, 28);
            this.label81.TabIndex = 1;
            this.label81.Text = "Their name?";
            // 
            // label82
            // 
            this.label82.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 285);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(202, 28);
            this.label82.TabIndex = 2;
            this.label82.Text = "Where they are?";
            // 
            // label83
            // 
            this.label83.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(3, 324);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(159, 28);
            this.label83.TabIndex = 3;
            this.label83.Text = "Time of day?";
            // 
            // label84
            // 
            this.label84.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(3, 363);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(252, 28);
            this.label84.TabIndex = 4;
            this.label84.Text = "Most recent activity?";
            // 
            // label85
            // 
            this.label85.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(3, 402);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(305, 28);
            this.label85.TabIndex = 5;
            this.label85.Text = "Speech is clear, correct?";
            // 
            // label86
            // 
            this.label86.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(3, 457);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(96, 32);
            this.label86.TabIndex = 6;
            this.label86.Text = "Sight:";
            // 
            // label87
            // 
            this.label87.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(3, 500);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(307, 28);
            this.label87.TabIndex = 7;
            this.label87.Text = "Correctly counts fingers?";
            // 
            // label88
            // 
            this.label88.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(3, 539);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(164, 28);
            this.label88.TabIndex = 8;
            this.label88.Text = "Vision clear?";
            // 
            // label89
            // 
            this.label89.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(3, 594);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(238, 32);
            this.label89.TabIndex = 9;
            this.label89.Text = "Eye Movements:";
            // 
            // label90
            // 
            this.label90.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(3, 637);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(297, 28);
            this.label90.TabIndex = 10;
            this.label90.Text = "Move all four directions?";
            // 
            // label91
            // 
            this.label91.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(3, 676);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(239, 28);
            this.label91.TabIndex = 11;
            this.label91.Text = "Nystagmus absent?";
            // 
            // label92
            // 
            this.label92.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(3, 731);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(271, 32);
            this.label92.TabIndex = 12;
            this.label92.Text = "Facial Movements:";
            // 
            // label93
            // 
            this.label93.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(3, 774);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(217, 28);
            this.label93.TabIndex = 13;
            this.label93.Text = "Teeth clench OK?";
            // 
            // label94
            // 
            this.label94.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(3, 813);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(310, 28);
            this.label94.TabIndex = 14;
            this.label94.Text = "Able to wrinkle forehead?";
            // 
            // label95
            // 
            this.label95.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(3, 852);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(350, 28);
            this.label95.TabIndex = 15;
            this.label95.Text = "Tongue moves all directions?";
            // 
            // label96
            // 
            this.label96.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(3, 891);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(240, 28);
            this.label96.TabIndex = 16;
            this.label96.Text = "Smile symmetrical?";
            // 
            // label97
            // 
            this.label97.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(3, 989);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(283, 28);
            this.label97.TabIndex = 17;
            this.label97.Text = "\"Adams Apple\" moves?";
            // 
            // label98
            // 
            this.label98.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(3, 1028);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(369, 28);
            this.label98.TabIndex = 18;
            this.label98.Text = "Shoulder shrug normal, equal?";
            // 
            // label99
            // 
            this.label99.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(3, 1067);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(390, 28);
            this.label99.TabIndex = 19;
            this.label99.Text = "Head movements normal, equal?";
            // 
            // label100
            // 
            this.label100.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(3, 1165);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(266, 28);
            this.label100.TabIndex = 20;
            this.label100.Text = "Normal for that diver?";
            // 
            // label101
            // 
            this.label101.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(3, 1204);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(207, 28);
            this.label101.TabIndex = 21;
            this.label101.Text = "Equal both ears?";
            // 
            // label102
            // 
            this.label102.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(3, 946);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(393, 32);
            this.label102.TabIndex = 22;
            this.label102.Text = "Head/Shoulder Movements:";
            // 
            // label103
            // 
            this.label103.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(3, 1122);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(134, 32);
            this.label103.TabIndex = 23;
            this.label103.Text = "Hearing:";
            // 
            // label104
            // 
            this.label104.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(3, 1259);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(176, 32);
            this.label104.TabIndex = 24;
            this.label104.Text = "Sensations:";
            // 
            // label105
            // 
            this.label105.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(3, 1302);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(68, 28);
            this.label105.TabIndex = 25;
            this.label105.Text = "Face";
            // 
            // label106
            // 
            this.label106.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(3, 1341);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(79, 28);
            this.label106.TabIndex = 26;
            this.label106.Text = "Chest";
            // 
            // label107
            // 
            this.label107.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(3, 1380);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(122, 28);
            this.label107.TabIndex = 27;
            this.label107.Text = "Abdomen";
            // 
            // label108
            // 
            this.label108.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(3, 1419);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(151, 28);
            this.label108.TabIndex = 28;
            this.label108.Text = "Arms (front)";
            // 
            // label109
            // 
            this.label109.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(3, 1458);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(86, 28);
            this.label109.TabIndex = 29;
            this.label109.Text = "Hands";
            // 
            // label110
            // 
            this.label110.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(3, 1497);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(145, 28);
            this.label110.TabIndex = 30;
            this.label110.Text = "Legs (front)";
            // 
            // label111
            // 
            this.label111.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(3, 1536);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(62, 28);
            this.label111.TabIndex = 31;
            this.label111.Text = "Feet";
            // 
            // label112
            // 
            this.label112.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(3, 1575);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(71, 28);
            this.label112.TabIndex = 32;
            this.label112.Text = "Back";
            // 
            // label113
            // 
            this.label113.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(3, 1614);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(153, 28);
            this.label113.TabIndex = 33;
            this.label113.Text = "Arms (back)";
            // 
            // label114
            // 
            this.label114.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(3, 1653);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(114, 28);
            this.label114.TabIndex = 34;
            this.label114.Text = "Buttocks";
            // 
            // label115
            // 
            this.label115.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(3, 1692);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(147, 28);
            this.label115.TabIndex = 35;
            this.label115.Text = "Legs (back)";
            // 
            // label116
            // 
            this.label116.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(3, 1747);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(197, 32);
            this.label116.TabIndex = 36;
            this.label116.Text = "Muscle Tone:";
            // 
            // label117
            // 
            this.label117.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(3, 1962);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(271, 32);
            this.label117.TabIndex = 37;
            this.label117.Text = "Facial Movements:";
            // 
            // label118
            // 
            this.label118.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(3, 2138);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(170, 32);
            this.label118.TabIndex = 38;
            this.label118.Text = "Vital Signs:";
            // 
            // label120
            // 
            this.label120.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(3, 1790);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(74, 28);
            this.label120.TabIndex = 40;
            this.label120.Text = "Arms";
            // 
            // label119
            // 
            this.label119.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(3, 1829);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(140, 28);
            this.label119.TabIndex = 41;
            this.label119.Text = "Hand grips";
            // 
            // label121
            // 
            this.label121.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(3, 1868);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(68, 28);
            this.label121.TabIndex = 42;
            this.label121.Text = "Legs";
            // 
            // label122
            // 
            this.label122.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(3, 1907);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(62, 28);
            this.label122.TabIndex = 43;
            this.label122.Text = "Feet";
            // 
            // label123
            // 
            this.label123.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(3, 2005);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(360, 28);
            this.label123.TabIndex = 44;
            this.label123.Text = "Romberg OK? (finger-to-nose)";
            // 
            // label124
            // 
            this.label124.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(3, 2044);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(353, 28);
            this.label124.TabIndex = 45;
            this.label124.Text = "If supine: Heel-shin slide OK?";
            // 
            // label125
            // 
            this.label125.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(3, 2083);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(399, 28);
            this.label125.TabIndex = 46;
            this.label125.Text = "Alternating hand movements OK?";
            // 
            // label126
            // 
            this.label126.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(3, 2181);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(190, 28);
            this.label126.TabIndex = 47;
            this.label126.Text = "Blood pressure";
            // 
            // label127
            // 
            this.label127.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(3, 2220);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(76, 28);
            this.label127.TabIndex = 48;
            this.label127.Text = "Pulse";
            // 
            // label128
            // 
            this.label128.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(3, 2259);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(159, 28);
            this.label128.TabIndex = 49;
            this.label128.Text = "Respirations";
            // 
            // label129
            // 
            this.label129.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(145, 66);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(274, 32);
            this.label129.TabIndex = 50;
            this.label129.Text = "Name of Examiner:";
            // 
            // label131
            // 
            this.label131.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(330, 105);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(89, 32);
            this.label131.TabIndex = 52;
            this.label131.Text = "Date:";
            // 
            // label132
            // 
            this.label132.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(170, 144);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(249, 32);
            this.label132.TabIndex = 53;
            this.label132.Text = "Initial Complaint:";
            // 
            // label130
            // 
            this.label130.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(202, 27);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(217, 32);
            this.label130.TabIndex = 51;
            this.label130.Text = "Name of Diver:";
            // 
            // comboBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.comboBox1, 5);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(445, 22);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(423, 35);
            this.comboBox1.TabIndex = 54;
            // 
            // textBox52
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.textBox52, 5);
            this.textBox52.Location = new System.Drawing.Point(445, 139);
            this.textBox52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(423, 34);
            this.textBox52.TabIndex = 55;
            // 
            // textBox53
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.textBox53, 5);
            this.textBox53.Location = new System.Drawing.Point(445, 61);
            this.textBox53.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(423, 34);
            this.textBox53.TabIndex = 56;
            // 
            // dateTimePicker2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.dateTimePicker2, 5);
            this.dateTimePicker2.Location = new System.Drawing.Point(445, 100);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(423, 34);
            this.dateTimePicker2.TabIndex = 57;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(445, 2250);
            this.radioButton13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(75, 32);
            this.radioButton13.TabIndex = 70;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Yes";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(445, 2211);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(75, 32);
            this.radioButton3.TabIndex = 60;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Yes";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(445, 2172);
            this.radioButton15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(75, 32);
            this.radioButton15.TabIndex = 72;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Yes";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(445, 2074);
            this.radioButton14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(75, 32);
            this.radioButton14.TabIndex = 71;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Yes";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(445, 2035);
            this.radioButton16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(75, 32);
            this.radioButton16.TabIndex = 73;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Yes";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(445, 1996);
            this.radioButton25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(75, 32);
            this.radioButton25.TabIndex = 82;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "Yes";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(445, 1781);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(75, 32);
            this.radioButton2.TabIndex = 59;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Yes";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(445, 1820);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(75, 32);
            this.radioButton4.TabIndex = 61;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Yes";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(445, 1859);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(75, 32);
            this.radioButton1.TabIndex = 58;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Yes";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(445, 1898);
            this.radioButton17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(75, 32);
            this.radioButton17.TabIndex = 74;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Yes";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(445, 1683);
            this.radioButton24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(75, 32);
            this.radioButton24.TabIndex = 81;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "Yes";
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(445, 1644);
            this.radioButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(75, 32);
            this.radioButton7.TabIndex = 64;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Yes";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(445, 1605);
            this.radioButton22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(75, 32);
            this.radioButton22.TabIndex = 79;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "Yes";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(445, 1566);
            this.radioButton27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(75, 32);
            this.radioButton27.TabIndex = 84;
            this.radioButton27.TabStop = true;
            this.radioButton27.Text = "Yes";
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Location = new System.Drawing.Point(445, 1527);
            this.radioButton29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(75, 32);
            this.radioButton29.TabIndex = 86;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "Yes";
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(445, 1488);
            this.radioButton26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(75, 32);
            this.radioButton26.TabIndex = 83;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "Yes";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(445, 1449);
            this.radioButton20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(75, 32);
            this.radioButton20.TabIndex = 77;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "Yes";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(445, 1410);
            this.radioButton28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(75, 32);
            this.radioButton28.TabIndex = 85;
            this.radioButton28.TabStop = true;
            this.radioButton28.Text = "Yes";
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(445, 1371);
            this.radioButton30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(75, 32);
            this.radioButton30.TabIndex = 87;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "Yes";
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(445, 1332);
            this.radioButton23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(75, 32);
            this.radioButton23.TabIndex = 80;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "Yes";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(445, 1293);
            this.radioButton21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(75, 32);
            this.radioButton21.TabIndex = 78;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "Yes";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(445, 1195);
            this.radioButton18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(75, 32);
            this.radioButton18.TabIndex = 75;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "Yes";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(445, 1156);
            this.radioButton19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(75, 32);
            this.radioButton19.TabIndex = 76;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Yes";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(445, 1058);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(75, 32);
            this.radioButton5.TabIndex = 62;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Yes";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(445, 1019);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(75, 32);
            this.radioButton6.TabIndex = 63;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Yes";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(445, 980);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(75, 32);
            this.radioButton8.TabIndex = 65;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Yes";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(445, 882);
            this.radioButton9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(75, 32);
            this.radioButton9.TabIndex = 66;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Yes";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(445, 843);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(75, 32);
            this.radioButton10.TabIndex = 67;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Yes";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(445, 804);
            this.radioButton11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(75, 32);
            this.radioButton11.TabIndex = 68;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Yes";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(445, 765);
            this.radioButton12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(75, 32);
            this.radioButton12.TabIndex = 69;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "Yes";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(445, 628);
            this.radioButton35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(75, 32);
            this.radioButton35.TabIndex = 92;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "Yes";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(445, 530);
            this.radioButton34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(75, 32);
            this.radioButton34.TabIndex = 91;
            this.radioButton34.TabStop = true;
            this.radioButton34.Text = "Yes";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(445, 491);
            this.radioButton33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(75, 32);
            this.radioButton33.TabIndex = 90;
            this.radioButton33.TabStop = true;
            this.radioButton33.Text = "Yes";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(445, 393);
            this.radioButton32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(75, 32);
            this.radioButton32.TabIndex = 89;
            this.radioButton32.TabStop = true;
            this.radioButton32.Text = "Yes";
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(445, 667);
            this.radioButton31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(75, 32);
            this.radioButton31.TabIndex = 88;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "Yes";
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(445, 354);
            this.radioButton39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(75, 32);
            this.radioButton39.TabIndex = 96;
            this.radioButton39.TabStop = true;
            this.radioButton39.Text = "Yes";
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(445, 315);
            this.radioButton38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(75, 32);
            this.radioButton38.TabIndex = 95;
            this.radioButton38.TabStop = true;
            this.radioButton38.Text = "Yes";
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(445, 276);
            this.radioButton37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(75, 32);
            this.radioButton37.TabIndex = 94;
            this.radioButton37.TabStop = true;
            this.radioButton37.Text = "Yes";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(445, 237);
            this.radioButton36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(75, 32);
            this.radioButton36.TabIndex = 93;
            this.radioButton36.TabStop = true;
            this.radioButton36.Text = "Yes";
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(570, 2211);
            this.radioButton40.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(65, 32);
            this.radioButton40.TabIndex = 97;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "No";
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(570, 2172);
            this.radioButton47.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(65, 32);
            this.radioButton47.TabIndex = 104;
            this.radioButton47.TabStop = true;
            this.radioButton47.Text = "No";
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(570, 2250);
            this.radioButton46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(65, 32);
            this.radioButton46.TabIndex = 103;
            this.radioButton46.TabStop = true;
            this.radioButton46.Text = "No";
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(570, 2074);
            this.radioButton41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(65, 32);
            this.radioButton41.TabIndex = 98;
            this.radioButton41.TabStop = true;
            this.radioButton41.Text = "No";
            this.radioButton41.UseVisualStyleBackColor = true;
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(570, 1996);
            this.radioButton44.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(65, 32);
            this.radioButton44.TabIndex = 101;
            this.radioButton44.TabStop = true;
            this.radioButton44.Text = "No";
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(570, 2035);
            this.radioButton45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(65, 32);
            this.radioButton45.TabIndex = 102;
            this.radioButton45.TabStop = true;
            this.radioButton45.Text = "No";
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(570, 1898);
            this.radioButton42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(65, 32);
            this.radioButton42.TabIndex = 99;
            this.radioButton42.TabStop = true;
            this.radioButton42.Text = "No";
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(570, 1859);
            this.radioButton43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(65, 32);
            this.radioButton43.TabIndex = 100;
            this.radioButton43.TabStop = true;
            this.radioButton43.Text = "No";
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(570, 1527);
            this.radioButton50.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(65, 32);
            this.radioButton50.TabIndex = 107;
            this.radioButton50.TabStop = true;
            this.radioButton50.Text = "No";
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(570, 1566);
            this.radioButton49.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(65, 32);
            this.radioButton49.TabIndex = 106;
            this.radioButton49.TabStop = true;
            this.radioButton49.Text = "No";
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(570, 1605);
            this.radioButton52.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(65, 32);
            this.radioButton52.TabIndex = 109;
            this.radioButton52.TabStop = true;
            this.radioButton52.Text = "No";
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(570, 1644);
            this.radioButton53.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(65, 32);
            this.radioButton53.TabIndex = 110;
            this.radioButton53.TabStop = true;
            this.radioButton53.Text = "No";
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(570, 1820);
            this.radioButton48.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(65, 32);
            this.radioButton48.TabIndex = 105;
            this.radioButton48.TabStop = true;
            this.radioButton48.Text = "No";
            this.radioButton48.UseVisualStyleBackColor = true;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(570, 1781);
            this.radioButton54.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(65, 32);
            this.radioButton54.TabIndex = 111;
            this.radioButton54.TabStop = true;
            this.radioButton54.Text = "No";
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(570, 1683);
            this.radioButton51.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(65, 32);
            this.radioButton51.TabIndex = 108;
            this.radioButton51.TabStop = true;
            this.radioButton51.Text = "No";
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(570, 1488);
            this.radioButton55.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(65, 32);
            this.radioButton55.TabIndex = 112;
            this.radioButton55.TabStop = true;
            this.radioButton55.Text = "No";
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(570, 1449);
            this.radioButton61.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(65, 32);
            this.radioButton61.TabIndex = 118;
            this.radioButton61.TabStop = true;
            this.radioButton61.Text = "No";
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(570, 1410);
            this.radioButton56.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(65, 32);
            this.radioButton56.TabIndex = 113;
            this.radioButton56.TabStop = true;
            this.radioButton56.Text = "No";
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(570, 1371);
            this.radioButton57.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(65, 32);
            this.radioButton57.TabIndex = 114;
            this.radioButton57.TabStop = true;
            this.radioButton57.Text = "No";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(570, 1332);
            this.radioButton58.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(65, 32);
            this.radioButton58.TabIndex = 115;
            this.radioButton58.TabStop = true;
            this.radioButton58.Text = "No";
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(570, 1293);
            this.radioButton59.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(65, 32);
            this.radioButton59.TabIndex = 116;
            this.radioButton59.TabStop = true;
            this.radioButton59.Text = "No";
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(570, 1195);
            this.radioButton60.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(65, 32);
            this.radioButton60.TabIndex = 117;
            this.radioButton60.TabStop = true;
            this.radioButton60.Text = "No";
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Location = new System.Drawing.Point(570, 1019);
            this.radioButton62.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(65, 32);
            this.radioButton62.TabIndex = 119;
            this.radioButton62.TabStop = true;
            this.radioButton62.Text = "No";
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Location = new System.Drawing.Point(570, 980);
            this.radioButton63.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(65, 32);
            this.radioButton63.TabIndex = 120;
            this.radioButton63.TabStop = true;
            this.radioButton63.Text = "No";
            this.radioButton63.UseVisualStyleBackColor = true;
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Location = new System.Drawing.Point(570, 1156);
            this.radioButton65.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(65, 32);
            this.radioButton65.TabIndex = 122;
            this.radioButton65.TabStop = true;
            this.radioButton65.Text = "No";
            this.radioButton65.UseVisualStyleBackColor = true;
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Location = new System.Drawing.Point(570, 1058);
            this.radioButton64.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(65, 32);
            this.radioButton64.TabIndex = 121;
            this.radioButton64.TabStop = true;
            this.radioButton64.Text = "No";
            this.radioButton64.UseVisualStyleBackColor = true;
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Location = new System.Drawing.Point(570, 882);
            this.radioButton66.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(65, 32);
            this.radioButton66.TabIndex = 123;
            this.radioButton66.TabStop = true;
            this.radioButton66.Text = "No";
            this.radioButton66.UseVisualStyleBackColor = true;
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Location = new System.Drawing.Point(570, 843);
            this.radioButton67.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(65, 32);
            this.radioButton67.TabIndex = 124;
            this.radioButton67.TabStop = true;
            this.radioButton67.Text = "No";
            this.radioButton67.UseVisualStyleBackColor = true;
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Location = new System.Drawing.Point(570, 804);
            this.radioButton68.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(65, 32);
            this.radioButton68.TabIndex = 125;
            this.radioButton68.TabStop = true;
            this.radioButton68.Text = "No";
            this.radioButton68.UseVisualStyleBackColor = true;
            // 
            // radioButton75
            // 
            this.radioButton75.AutoSize = true;
            this.radioButton75.Location = new System.Drawing.Point(570, 667);
            this.radioButton75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton75.Name = "radioButton75";
            this.radioButton75.Size = new System.Drawing.Size(65, 32);
            this.radioButton75.TabIndex = 132;
            this.radioButton75.TabStop = true;
            this.radioButton75.Text = "No";
            this.radioButton75.UseVisualStyleBackColor = true;
            // 
            // radioButton74
            // 
            this.radioButton74.AutoSize = true;
            this.radioButton74.Location = new System.Drawing.Point(570, 628);
            this.radioButton74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton74.Name = "radioButton74";
            this.radioButton74.Size = new System.Drawing.Size(65, 32);
            this.radioButton74.TabIndex = 131;
            this.radioButton74.TabStop = true;
            this.radioButton74.Text = "No";
            this.radioButton74.UseVisualStyleBackColor = true;
            // 
            // radioButton73
            // 
            this.radioButton73.AutoSize = true;
            this.radioButton73.Location = new System.Drawing.Point(570, 530);
            this.radioButton73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton73.Name = "radioButton73";
            this.radioButton73.Size = new System.Drawing.Size(65, 32);
            this.radioButton73.TabIndex = 130;
            this.radioButton73.TabStop = true;
            this.radioButton73.Text = "No";
            this.radioButton73.UseVisualStyleBackColor = true;
            // 
            // radioButton72
            // 
            this.radioButton72.AutoSize = true;
            this.radioButton72.Location = new System.Drawing.Point(570, 491);
            this.radioButton72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton72.Name = "radioButton72";
            this.radioButton72.Size = new System.Drawing.Size(65, 32);
            this.radioButton72.TabIndex = 129;
            this.radioButton72.TabStop = true;
            this.radioButton72.Text = "No";
            this.radioButton72.UseVisualStyleBackColor = true;
            // 
            // radioButton71
            // 
            this.radioButton71.AutoSize = true;
            this.radioButton71.Location = new System.Drawing.Point(570, 393);
            this.radioButton71.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton71.Name = "radioButton71";
            this.radioButton71.Size = new System.Drawing.Size(65, 32);
            this.radioButton71.TabIndex = 128;
            this.radioButton71.TabStop = true;
            this.radioButton71.Text = "No";
            this.radioButton71.UseVisualStyleBackColor = true;
            // 
            // radioButton70
            // 
            this.radioButton70.AutoSize = true;
            this.radioButton70.Location = new System.Drawing.Point(570, 354);
            this.radioButton70.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton70.Name = "radioButton70";
            this.radioButton70.Size = new System.Drawing.Size(65, 32);
            this.radioButton70.TabIndex = 127;
            this.radioButton70.TabStop = true;
            this.radioButton70.Text = "No";
            this.radioButton70.UseVisualStyleBackColor = true;
            // 
            // radioButton69
            // 
            this.radioButton69.AutoSize = true;
            this.radioButton69.Location = new System.Drawing.Point(570, 765);
            this.radioButton69.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton69.Name = "radioButton69";
            this.radioButton69.Size = new System.Drawing.Size(65, 32);
            this.radioButton69.TabIndex = 126;
            this.radioButton69.TabStop = true;
            this.radioButton69.Text = "No";
            this.radioButton69.UseVisualStyleBackColor = true;
            // 
            // radioButton78
            // 
            this.radioButton78.AutoSize = true;
            this.radioButton78.Location = new System.Drawing.Point(570, 315);
            this.radioButton78.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton78.Name = "radioButton78";
            this.radioButton78.Size = new System.Drawing.Size(65, 32);
            this.radioButton78.TabIndex = 135;
            this.radioButton78.TabStop = true;
            this.radioButton78.Text = "No";
            this.radioButton78.UseVisualStyleBackColor = true;
            // 
            // radioButton77
            // 
            this.radioButton77.AutoSize = true;
            this.radioButton77.Location = new System.Drawing.Point(570, 276);
            this.radioButton77.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton77.Name = "radioButton77";
            this.radioButton77.Size = new System.Drawing.Size(65, 32);
            this.radioButton77.TabIndex = 134;
            this.radioButton77.TabStop = true;
            this.radioButton77.Text = "No";
            this.radioButton77.UseVisualStyleBackColor = true;
            // 
            // radioButton76
            // 
            this.radioButton76.AutoSize = true;
            this.radioButton76.Location = new System.Drawing.Point(570, 237);
            this.radioButton76.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton76.Name = "radioButton76";
            this.radioButton76.Size = new System.Drawing.Size(65, 32);
            this.radioButton76.TabIndex = 133;
            this.radioButton76.TabStop = true;
            this.radioButton76.Text = "No";
            this.radioButton76.UseVisualStyleBackColor = true;
            // 
            // label133
            // 
            this.label133.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.Location = new System.Drawing.Point(695, 203);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(104, 32);
            this.label133.TabIndex = 136;
            this.label133.Text = "Notes:";
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(695, 2250);
            this.textBox56.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox56.Multiline = true;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(417, 34);
            this.textBox56.TabIndex = 139;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(695, 2211);
            this.textBox55.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox55.Multiline = true;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(417, 34);
            this.textBox55.TabIndex = 138;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(695, 2172);
            this.textBox59.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox59.Multiline = true;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(417, 34);
            this.textBox59.TabIndex = 142;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(695, 2074);
            this.textBox54.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox54.Multiline = true;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(417, 34);
            this.textBox54.TabIndex = 137;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(695, 2035);
            this.textBox60.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox60.Multiline = true;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(417, 34);
            this.textBox60.TabIndex = 143;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(695, 1996);
            this.textBox61.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox61.Multiline = true;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(417, 34);
            this.textBox61.TabIndex = 144;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(695, 1898);
            this.textBox62.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox62.Multiline = true;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(417, 34);
            this.textBox62.TabIndex = 145;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(695, 1859);
            this.textBox58.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox58.Multiline = true;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(417, 34);
            this.textBox58.TabIndex = 141;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(695, 1820);
            this.textBox57.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox57.Multiline = true;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(417, 34);
            this.textBox57.TabIndex = 140;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(695, 1781);
            this.textBox69.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox69.Multiline = true;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(417, 34);
            this.textBox69.TabIndex = 152;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(695, 1683);
            this.textBox66.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(417, 34);
            this.textBox66.TabIndex = 149;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(695, 1644);
            this.textBox68.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox68.Multiline = true;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(417, 34);
            this.textBox68.TabIndex = 151;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(695, 1605);
            this.textBox67.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox67.Multiline = true;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(417, 34);
            this.textBox67.TabIndex = 150;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(695, 1566);
            this.textBox64.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox64.Multiline = true;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(417, 34);
            this.textBox64.TabIndex = 147;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(695, 1527);
            this.textBox65.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox65.Multiline = true;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(417, 34);
            this.textBox65.TabIndex = 148;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(695, 1488);
            this.textBox63.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox63.Multiline = true;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(417, 34);
            this.textBox63.TabIndex = 146;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(695, 1449);
            this.textBox70.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox70.Multiline = true;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(417, 34);
            this.textBox70.TabIndex = 153;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(695, 1410);
            this.textBox72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox72.Multiline = true;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(417, 34);
            this.textBox72.TabIndex = 155;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(695, 1371);
            this.textBox73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox73.Multiline = true;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(417, 34);
            this.textBox73.TabIndex = 156;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(695, 1332);
            this.textBox74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox74.Multiline = true;
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(417, 34);
            this.textBox74.TabIndex = 157;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(695, 1293);
            this.textBox76.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox76.Multiline = true;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(417, 34);
            this.textBox76.TabIndex = 159;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(695, 1195);
            this.textBox75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox75.Multiline = true;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(417, 34);
            this.textBox75.TabIndex = 158;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(695, 1156);
            this.textBox71.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox71.Multiline = true;
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(417, 34);
            this.textBox71.TabIndex = 154;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(695, 1019);
            this.textBox77.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox77.Multiline = true;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(417, 34);
            this.textBox77.TabIndex = 160;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(695, 980);
            this.textBox78.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox78.Multiline = true;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(417, 34);
            this.textBox78.TabIndex = 161;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(695, 1058);
            this.textBox79.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox79.Multiline = true;
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(417, 34);
            this.textBox79.TabIndex = 162;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(695, 882);
            this.textBox82.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox82.Multiline = true;
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(417, 34);
            this.textBox82.TabIndex = 165;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(695, 843);
            this.textBox80.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox80.Multiline = true;
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(417, 34);
            this.textBox80.TabIndex = 163;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(695, 804);
            this.textBox81.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox81.Multiline = true;
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(417, 34);
            this.textBox81.TabIndex = 164;
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(695, 765);
            this.textBox83.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox83.Multiline = true;
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(417, 34);
            this.textBox83.TabIndex = 166;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(695, 628);
            this.textBox90.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox90.Multiline = true;
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(417, 34);
            this.textBox90.TabIndex = 173;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(695, 667);
            this.textBox89.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(417, 34);
            this.textBox89.TabIndex = 172;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(695, 530);
            this.textBox88.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox88.Multiline = true;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(417, 34);
            this.textBox88.TabIndex = 171;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(695, 491);
            this.textBox87.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox87.Multiline = true;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(417, 34);
            this.textBox87.TabIndex = 170;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(695, 393);
            this.textBox86.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox86.Multiline = true;
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(417, 34);
            this.textBox86.TabIndex = 169;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(695, 354);
            this.textBox85.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox85.Multiline = true;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(417, 34);
            this.textBox85.TabIndex = 168;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(695, 315);
            this.textBox84.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox84.Multiline = true;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(417, 34);
            this.textBox84.TabIndex = 167;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(695, 276);
            this.textBox92.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox92.Multiline = true;
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(417, 34);
            this.textBox92.TabIndex = 175;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(695, 237);
            this.textBox91.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox91.Multiline = true;
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(417, 34);
            this.textBox91.TabIndex = 174;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(4, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 39);
            this.label1.TabIndex = 4;
            this.label1.Text = "Active Dive";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(2, 290);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(281, 28);
            this.label134.TabIndex = 24;
            this.label134.Text = "Air Check 2 (Time/PSI):";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(7, 325);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(160, 34);
            this.textBox7.TabIndex = 25;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(185, 325);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(160, 34);
            this.textBox8.TabIndex = 26;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label135.Location = new System.Drawing.Point(3, 368);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(281, 28);
            this.label135.TabIndex = 27;
            this.label135.Text = "Air Check 3 (Time/PSI):";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(6, 404);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(160, 34);
            this.textBox9.TabIndex = 28;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(184, 404);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(160, 34);
            this.textBox10.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.textBox12);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.textBox13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.textBox14);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.maskedTextBox1);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.textBox17);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.textBox18);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Location = new System.Drawing.Point(0, 506);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(363, 889);
            this.panel1.TabIndex = 12;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(184, 404);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(160, 34);
            this.textBox5.TabIndex = 29;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(6, 404);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(160, 34);
            this.textBox6.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 368);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(281, 28);
            this.label9.TabIndex = 27;
            this.label9.Text = "Air Check 3 (Time/PSI):";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(185, 325);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(160, 34);
            this.textBox11.TabIndex = 26;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(7, 325);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(160, 34);
            this.textBox12.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(2, 290);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(281, 28);
            this.label10.TabIndex = 24;
            this.label10.Text = "Air Check 2 (Time/PSI):";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Gray;
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Location = new System.Drawing.Point(62, 807);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(221, 43);
            this.button8.TabIndex = 23;
            this.button8.Text = "New Segment";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(6, 654);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(338, 136);
            this.textBox13.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 620);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(309, 28);
            this.label11.TabIndex = 21;
            this.label11.Text = "Dive Segment Comments:";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(5, 573);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(340, 34);
            this.textBox14.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 537);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 28);
            this.label12.TabIndex = 19;
            this.label12.Text = "Depth:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(8, 487);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maskedTextBox1.Mask = "00:00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(336, 39);
            this.maskedTextBox1.TabIndex = 18;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(3, 450);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(331, 28);
            this.label60.TabIndex = 17;
            this.label60.Text = "Time Out of Water(Military):";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(184, 244);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(160, 34);
            this.textBox15.TabIndex = 16;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(7, 244);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(160, 34);
            this.textBox16.TabIndex = 15;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(5, 210);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(281, 28);
            this.label61.TabIndex = 14;
            this.label61.Text = "Air Check 1 (Time/PSI):";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(7, 162);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(340, 34);
            this.textBox17.TabIndex = 13;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(3, 128);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(180, 28);
            this.label62.TabIndex = 12;
            this.label62.Text = "Time in Water:";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(7, 85);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(340, 34);
            this.textBox18.TabIndex = 11;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(3, 50);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(200, 28);
            this.label68.TabIndex = 10;
            this.label68.Text = "Starting Air PSI:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label69.Location = new System.Drawing.Point(3, 0);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(245, 39);
            this.label69.TabIndex = 7;
            this.label69.Text = "Dive Segment";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Controls.Add(this.textBox19);
            this.panel3.Controls.Add(this.textBox20);
            this.panel3.Controls.Add(this.label70);
            this.panel3.Controls.Add(this.textBox21);
            this.panel3.Controls.Add(this.textBox22);
            this.panel3.Controls.Add(this.label76);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.textBox23);
            this.panel3.Controls.Add(this.label77);
            this.panel3.Controls.Add(this.textBox24);
            this.panel3.Controls.Add(this.label78);
            this.panel3.Controls.Add(this.maskedTextBox2);
            this.panel3.Controls.Add(this.label79);
            this.panel3.Controls.Add(this.textBox25);
            this.panel3.Controls.Add(this.textBox26);
            this.panel3.Controls.Add(this.label136);
            this.panel3.Controls.Add(this.textBox27);
            this.panel3.Controls.Add(this.label137);
            this.panel3.Controls.Add(this.textBox28);
            this.panel3.Controls.Add(this.label138);
            this.panel3.Controls.Add(this.label139);
            this.panel3.Location = new System.Drawing.Point(0, 506);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(363, 889);
            this.panel3.TabIndex = 12;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(184, 404);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(160, 34);
            this.textBox19.TabIndex = 29;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(6, 404);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(160, 34);
            this.textBox20.TabIndex = 28;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(3, 368);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(281, 28);
            this.label70.TabIndex = 27;
            this.label70.Text = "Air Check 3 (Time/PSI):";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(185, 325);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(160, 34);
            this.textBox21.TabIndex = 26;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(7, 325);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(160, 34);
            this.textBox22.TabIndex = 25;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(2, 290);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(281, 28);
            this.label76.TabIndex = 24;
            this.label76.Text = "Air Check 2 (Time/PSI):";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Gray;
            this.button9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button9.Location = new System.Drawing.Point(62, 807);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(221, 43);
            this.button9.TabIndex = 23;
            this.button9.Text = "New Segment";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(6, 654);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(338, 136);
            this.textBox23.TabIndex = 22;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(4, 620);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(309, 28);
            this.label77.TabIndex = 21;
            this.label77.Text = "Dive Segment Comments:";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(5, 573);
            this.textBox24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(340, 34);
            this.textBox24.TabIndex = 20;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(6, 537);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(89, 28);
            this.label78.TabIndex = 19;
            this.label78.Text = "Depth:";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(8, 487);
            this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maskedTextBox2.Mask = "00:00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(336, 39);
            this.maskedTextBox2.TabIndex = 18;
            this.maskedTextBox2.ValidatingType = typeof(System.DateTime);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(3, 450);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(331, 28);
            this.label79.TabIndex = 17;
            this.label79.Text = "Time Out of Water(Military):";
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(184, 244);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(160, 34);
            this.textBox25.TabIndex = 16;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(7, 244);
            this.textBox26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(160, 34);
            this.textBox26.TabIndex = 15;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.Location = new System.Drawing.Point(5, 210);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(281, 28);
            this.label136.TabIndex = 14;
            this.label136.Text = "Air Check 1 (Time/PSI):";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(7, 162);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(340, 34);
            this.textBox27.TabIndex = 13;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.Location = new System.Drawing.Point(3, 128);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(180, 28);
            this.label137.TabIndex = 12;
            this.label137.Text = "Time in Water:";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(7, 85);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(340, 34);
            this.textBox28.TabIndex = 11;
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label138.Location = new System.Drawing.Point(3, 50);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(200, 28);
            this.label138.TabIndex = 10;
            this.label138.Text = "Starting Air PSI:";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label139.Location = new System.Drawing.Point(3, 0);
            this.label139.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(245, 39);
            this.label139.TabIndex = 7;
            this.label139.Text = "Dive Segment";
            // 
            // Start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1339, 884);
            this.Controls.Add(this.activeDivePanel);
            this.Controls.Add(this.startPanel);
            this.Controls.Add(this.preDivePanel);
            this.Controls.Add(this.postDivePanel);
            this.Controls.Add(this.diverLogPanel);
            this.Controls.Add(this.reportPanel);
            this.Controls.Add(this.postDiveButton);
            this.Controls.Add(this.activeDiveButton);
            this.Controls.Add(this.preDiveButton);
            this.Controls.Add(this.reportButton);
            this.Controls.Add(this.diverLogButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.toolbar);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximumSize = new System.Drawing.Size(1357, 931);
            this.MinimumSize = new System.Drawing.Size(1357, 931);
            this.Name = "Start";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dive Application";
            this.Load += new System.EventHandler(this.Start_Load);
            this.toolbar.ResumeLayout(false);
            this.toolbar.PerformLayout();
            this.startPanel.ResumeLayout(false);
            this.startPanel.PerformLayout();
            this.startPanelForm.ResumeLayout(false);
            this.diverLogPanel.ResumeLayout(false);
            this.diverLogPanel.PerformLayout();
            this.diverLogFormPanel.ResumeLayout(false);
            this.diverLogFormPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.reportPanel.ResumeLayout(false);
            this.reportPanel.PerformLayout();
            this.preDivePanel.ResumeLayout(false);
            this.preDivePanel.PerformLayout();
            this.preDiveFormPanel.ResumeLayout(false);
            this.preDiveTable.ResumeLayout(false);
            this.preDiveTable.PerformLayout();
            this.postDivePanel.ResumeLayout(false);
            this.postDivePanel.PerformLayout();
            this.postDiveFormPanel.ResumeLayout(false);
            this.debriefTable.ResumeLayout(false);
            this.debriefTable.PerformLayout();
            this.activeDivePanel.ResumeLayout(false);
            this.activeDivePanel.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.activeDiveTable.ResumeLayout(false);
            this.activeDiveTable.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolbar;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button diverLogButton;
        private System.Windows.Forms.Button reportButton;
        private System.Windows.Forms.Button preDiveButton;
        private System.Windows.Forms.Button activeDiveButton;
        private System.Windows.Forms.Button postDiveButton;
        private System.Windows.Forms.Panel startPanel;
        private System.Windows.Forms.Panel diverLogPanel;
        private System.Windows.Forms.Label startLabel;
        private System.Windows.Forms.Panel reportPanel;
        private System.Windows.Forms.Label diverLogLabel;
        private System.Windows.Forms.Label reportLabel;
        private System.Windows.Forms.Panel preDivePanel;
        private System.Windows.Forms.Label preDiveLabel;
        private System.Windows.Forms.Panel postDivePanel;
        private System.Windows.Forms.Label postDiveLabel;
        private System.Windows.Forms.Panel diverLogFormPanel;
        private System.Windows.Forms.Panel reportFormPanel;
        private System.Windows.Forms.Panel postDiveFormPanel;
        private System.Windows.Forms.DateTimePicker debriefDateTimePicker;
        private System.Windows.Forms.Label debriefDateTimeLabel;
        private System.Windows.Forms.TableLayoutPanel debriefTable;
        private System.Windows.Forms.Label debriefVesselLabel;
        private System.Windows.Forms.TextBox debriefVesselText;
        private System.Windows.Forms.TextBox debriefEquipmentText;
        private System.Windows.Forms.Label debriefEquipmentLabel;
        private System.Windows.Forms.Label debriefInjuriesLabel;
        private System.Windows.Forms.TextBox debriefInjuriesText;
        private System.Windows.Forms.TextBox debriefPropertyText;
        private System.Windows.Forms.Label debriefInjuriesSupervisorLabel;
        private System.Windows.Forms.Label debriefPropertyLabel;
        private System.Windows.Forms.Label debriefPropertySupervisorLabel;
        private System.Windows.Forms.ComboBox debriefPropertySupervisorCombo;
        private System.Windows.Forms.TextBox debriefWorkedWellText;
        private System.Windows.Forms.TextBox debriefNotWorkedWellText;
        private System.Windows.Forms.Label debriefWorkedWellLabel;
        private System.Windows.Forms.Label debriefNotWorkedWellLabel;
        private System.Windows.Forms.ComboBox debriefInjuriesSupervisorCombo;
        private System.Windows.Forms.Button addDiver;
        private System.Windows.Forms.Panel activeDivePanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel preDiveFormPanel;
        private System.Windows.Forms.TableLayoutPanel preDiveTable;
        private System.Windows.Forms.Label preReportLabel;
        private System.Windows.Forms.DateTimePicker preDateTimePicker;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox preReportNum;
        private System.Windows.Forms.Label preStateMissionLabel;
        private System.Windows.Forms.TextBox preStateMissionNum;
        private System.Windows.Forms.Label preOpCompletionLabel;
        private System.Windows.Forms.Label preCaseInvestigatorLabel;
        private System.Windows.Forms.TextBox preOpPlanCompletedBy;
        private System.Windows.Forms.TextBox preCaseInvestigator;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox preBriefingLocation;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox preSituation;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox preTypeOfOperation;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox preAnticipatedDate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox preAnticipatedTime;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox preLocationAndDescription;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox preSiteSurvey;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox preWitnessName;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.MaskedTextBox preWitnessPhone;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox preWitnessAddress;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox preVehicleMake;
        private System.Windows.Forms.TextBox preVehicleModel;
        private System.Windows.Forms.TextBox preVehicleYear;
        private System.Windows.Forms.TextBox preVehicleColor;
        private System.Windows.Forms.TextBox preVehiclePlate;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox preSceneAssessment;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox preWaterFlow;
        private System.Windows.Forms.TextBox preWaterDepth;
        private System.Windows.Forms.TextBox preWaterTemp;
        private System.Windows.Forms.TextBox preWaterVisibility;
        private System.Windows.Forms.TextBox preWaterHazards;
        private System.Windows.Forms.TextBox preWaterObstructions;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox preLightning;
        private System.Windows.Forms.TextBox preAccess;
        private System.Windows.Forms.TextBox preOtherThreats;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox preOperationObjectives;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox prePersonnelInvolved;
        private System.Windows.Forms.TextBox preVehiclesInvolved;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox prePrimaryRadioChannel;
        private System.Windows.Forms.TextBox preSecondaryRadioChannel;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox prePrimarySubsurfaceChannel;
        private System.Windows.Forms.TextBox preSecondarySubsurfaceChannel;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox preStandardDiveGear;
        private System.Windows.Forms.CheckBox preSrandardSwiftwaterGear;
        private System.Windows.Forms.CheckBox preStandardTenderGear;
        private System.Windows.Forms.CheckBox preStandardIceRescueGear;
        private System.Windows.Forms.CheckBox preOtherGear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox prePatrolSupervisor;
        private System.Windows.Forms.CheckBox preAvistaGCC;
        private System.Windows.Forms.CheckBox preDispatch;
        private System.Windows.Forms.CheckBox preUpriverDam;
        private System.Windows.Forms.CheckBox preDeaconessHyperbaricChamber;
        private System.Windows.Forms.CheckBox preShiftCommander;
        private System.Windows.Forms.CheckBox preOtherNotifications;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel activeDiveTable;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel startPanelForm;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.RadioButton radioButton75;
        private System.Windows.Forms.RadioButton radioButton74;
        private System.Windows.Forms.RadioButton radioButton73;
        private System.Windows.Forms.RadioButton radioButton72;
        private System.Windows.Forms.RadioButton radioButton71;
        private System.Windows.Forms.RadioButton radioButton70;
        private System.Windows.Forms.RadioButton radioButton69;
        private System.Windows.Forms.RadioButton radioButton78;
        private System.Windows.Forms.RadioButton radioButton77;
        private System.Windows.Forms.RadioButton radioButton76;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox diverName;
        private System.Windows.Forms.TextBox diverList;
        private System.Windows.Forms.Button removeDiver;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label134;
    }
}

