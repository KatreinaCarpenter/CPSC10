﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.IO;

namespace WindowsFormsApplication2
{
    public class DBTable
    {
        public Dictionary<string, string> data = new Dictionary<string, string>();
        public string tableName = "";
        public string insertString = "";
        public string createString = "";
        public string values = "";
        public string primaryKey = "";
        public string foreignKey = "";

        public DBTable()
        {

        }

        public void setName(string name)
        {
            this.tableName = name;
        }

        public void setCreateString()
        {
            createString = "";
            createString = "CREATE TABLE " + tableName + " (";
            foreach (KeyValuePair<string, string> entry in data)
                createString += (entry.Key + " TEXT, ");
            createString += primaryKey;
            createString += ")";
        }

        public void setInsertString()
        {
            insertString = "";
            insertString = "INSERT INTO " + tableName + " (";
            foreach (KeyValuePair<string, string> entry in data)
                insertString += (entry.Key + ", ");
            insertString = insertString.Remove(insertString.Length - 2);
            insertString += ") VALUES (" + values + ");";
            Console.WriteLine(insertString);
        }

        public void setValues()
        {
            values = "";
            foreach (KeyValuePair<string, string> entry in data)
                values += ("'" + entry.Value + "', ");
            values = values.Remove(values.Length - 2);
        }

        public void setPrimaryKey(string tableName)
        {
            if (tableName == "Operation")
            {
                primaryKey = "PRIMARY KEY(preReportNum)";
            }
            else if (tableName == "Diver")
            {
                primaryKey = "PRIMARY KEY(name)";
                data.Add("name", "");
            }
        }

        public void setForeignKey(string tableName)
        {

        }
             
        
    }
}
