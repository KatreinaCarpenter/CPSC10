﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    class DiveDB
    {
        /*
        // create or open database file and establish connection
        public static void initialize()
        {

            // check for database file "Database.sql"
            if (File.Exists(".\\Database.sqlite"))
            {
                connection = new SQLiteConnection("Data Source=Database.sqlite;Version=3;");
                connection.Open();
            }
            // if it doesn't exist create one 
            else
            {
                SQLiteConnection.CreateFile("Database.sqlite");
                connection = new SQLiteConnection("Data Source=Database.sqlite;Version=3;");
                connection.Open();
            }
        }
        // create tables 
        public static void createTables()
        {

            // create the operation table
            statement = "CREATE TABLE Operation (";
            statement += "operation_number TEXT REFERENCES Operation_Plan(operation_number), ";
            statement += "PRIMARY KEY(operation_number))";
            command = new SQLiteCommand(statement, connection);
            command.ExecuteNonQuery();

            // create the diver table
            statement = "CREATE TABLE Diver (";
            statement += "diver_id TEXT, ";
            statement += "full_name TEXT, ";
            statement += "PRIMARY KEY(diver_id))";
            command = new SQLiteCommand(statement, connection);
            command.ExecuteNonQuery();

            // create the neuro table
            statement = "CREATE TABLE Neuro_Test (";
            statement += "operation_number TEXT REFERENCES Operation_Plan(operation_number), ";
            statement += "diver_id TEXT REFERENCES Diver(diver_id), ";
            statement += "time TEXT, ";
            statement += "PRIMARY KEY(operation_number, diver_id, time))";
            command = new SQLiteCommand(statement, connection);
            command.ExecuteNonQuery();

            // create the dive segment table
            statement = "CREATE TABLE Dive_Segment (";
            statement += "operation_number TEXT REFERENCES Operation_Plan(operation_number), ";
            statement += "diver_id TEXT REFERENCES Diver(diver_id), ";
            statement += "role TEXT, ";
            statement += "segment_number TEXT, ";
            statement += "PRIMARY KEY(operation_number, diver_id, role, segment_number))";
            command = new SQLiteCommand(statement, connection);
            command.ExecuteNonQuery();

        }
        // insert an instance into a table
        public static void insert(string table, SQLiteConnection connection)
        {
            /*
            // insert a row into the diver table
            statement = "INSERT INTO Operation_Plan (preReportNum, ...) VALUES (1, ....)
            command = new SQLiteCommand(sql, connection);
            command.ExecuteNonQuery();
            */

        /*
        }

        // query function
        public static void query(string statement)
        {
            /*
            // query the tables and read the result back
            // (return neuro result and name for every diver) 
            sql = "select passed, name from diver, neuro on diver.diver_id == neuro.diver_id";
            command = new SQLiteCommand(sql, Connection);

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
                Console.WriteLine(reader.GetBoolean(0) + " " + reader.GetString(1));
            Console.Read();
            Connection.Close();
            *//*
        }

        // data members
        private static SQLiteConnection connection;
        private static string statement;
        private static SQLiteCommand command;  // command consists of a sql statement and a connection
        */
    }
}
