﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DiveApp;

namespace DiveAppTests
{
    [TestClass]
    public class DiveAppTests
    {
        [TestMethod]
        public void setInjuriesBoolTest()
        {
            int falseInt = 0;

            DiveDB myDive = new DiveDB();

            myDive.setInjuriesBool(falseInt);

            bool expected = false;
            int actual = falseInt;

            Assert.AreEqual(expected, actual);
           
        }
    }
}
