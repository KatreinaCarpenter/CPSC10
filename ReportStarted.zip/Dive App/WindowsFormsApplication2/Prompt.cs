﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    class Prompt
    {
        public static string ShowDialog(string text, string caption, List<string> choices)
        {
            Form prompt = new Form();
            prompt.StartPosition = FormStartPosition.CenterScreen;
            prompt.Width = 350;
            prompt.Height = 200;
            prompt.Text = caption;
            Label textLabel = new Label() { Left = 50, Top = 40, Text = caption };
            ComboBox inputBox = new ComboBox() { Left = 50, Top = 70, Text = text };
            foreach (string str in choices)
            {
                inputBox.Items.Add(str);
            }
            Button confirmation = new Button() { Text = "Ok", Left = 200, Width = 100, Top = 69 };
            string strToReturn = text;
            confirmation.Click += (sender, e) => {
                strToReturn = inputBox.Text;
                prompt.Close(); };
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(inputBox);
            prompt.ShowDialog();
            return strToReturn;// inputBox.Text;
        }
    }
}
