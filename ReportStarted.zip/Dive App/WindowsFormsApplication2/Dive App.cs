﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Start : Form
    {
        public DBTable operationTable = new DBTable();
        public DBTable diverTable = new DBTable();
        public SQLiteConnection connection;
        public SQLiteCommand command;

        public Start()
        {
            InitializeComponent();
            clearFields();
            initializeDB();
            showOperationButtons(false);
            setActiveButtonColor(startButton);
            switchToPanel(startPanel);
            generateDiverList();
        }

        private void populateComboBoxOptions()
        {
            populateComboBoxOptions(debriefInjuriesSupervisorCombo);
            populateComboBoxOptions(debriefPropertySupervisorCombo);
        }

        private void populateComboBoxOptions(ComboBox combo)
        {
            List<string> diverNames = generateDivers();
            combo.Items.Clear();
            foreach (string name in diverNames)
            {
                combo.Items.Add(name);
            }

        }

        private void generateDiverList()
        {
            string diverListOutput = "";
            List<string> diverNames = generateDivers();
            foreach (string name in diverNames)
            {
                diverListOutput += name + "\r\n";
            }
            diverList.Text = diverListOutput;
            populateComboBoxOptions();
        }

        public void populateOperationTableData(string reportNum)
        {
            List<string> keys = new List<string>();
            foreach (KeyValuePair<string, string> entry in operationTable.data)
            {
                keys.Add(entry.Key);
            }
            foreach (string str in keys)
            { 
                command = new SQLiteCommand("SELECT " + str + " FROM Operation WHERE preReportNum == " + "'" + reportNum + "'", connection);
                SQLiteDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    operationTable.data[str] = reader.GetString(0);
                }                
            }
        }

        public void showOperationButtons(bool isVisible)
        {
            preDiveButton.Visible = isVisible;
            activeDiveButton.Visible = isVisible;
            postDiveButton.Visible = isVisible;
        }

        public List<string> generateReportNumbers()
        {
            List<string> reportNumbers = new List<string>();

            command = new SQLiteCommand("SELECT preReportNum FROM Operation", connection);
            
            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
                reportNumbers.Add(reader.GetString(0));
            reportNumbers.Sort();
            return reportNumbers;
        }

        public List<string> generateDivers()
        {
            List<string> divers = new List<string>();

            command = new SQLiteCommand("SELECT name FROM Diver", connection);

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
                divers.Add(reader.GetString(0));
            divers.Sort();
            return divers;
        }

        private void initializeDB()
        {
            operationTable.setName("Operation");
            operationTable.setPrimaryKey("Operation");

            diverTable.setName("Diver");
            diverTable.setPrimaryKey("Diver");

            if (File.Exists(".\\Database.sqlite"))
            {
                connection = new SQLiteConnection("Data Source=Database.sqlite;Version=3;");
                connection.Open();

            }
            // if it doesn't exist create one 
            else
            {
                SQLiteConnection.CreateFile("Database.sqlite");
                connection = new SQLiteConnection("Data Source=Database.sqlite;Version=3;");
                connection.Open();

                //create Operation Table
                operationTable.setCreateString();
                command = new SQLiteCommand(operationTable.createString, connection);
                command.ExecuteNonQuery();

                diverTable.setCreateString();
                command = new SQLiteCommand(diverTable.createString, connection);
                command.ExecuteNonQuery();
            }
        }

        private void insertOperationData()
        {
            List<string> reportNumbers = generateReportNumbers();
            if (reportNumbers.Contains(operationTable.data["preReportNum"]))
            {

                DialogResult overwriteEntry = MessageBox.Show("Are you sure you would like to overwrite the existing dive?", "Overwrite Dive", MessageBoxButtons.YesNo);
                if(overwriteEntry == DialogResult.Yes)
                {
                    string dropRow = "DELETE FROM Operation WHERE preReportNum ==" + "'" + operationTable.data["preReportNum"] + "'";
                    command = new SQLiteCommand(dropRow, connection);
                    command.ExecuteNonQuery();

                    operationTable.setValues();
                    operationTable.setInsertString();
                    command = new SQLiteCommand(operationTable.insertString, connection);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Save successful", "Save", MessageBoxButtons.OK);
                }
            }
            else
            {
                operationTable.setValues();
                operationTable.setInsertString();
                command = new SQLiteCommand(operationTable.insertString, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Save successful", "Save", MessageBoxButtons.OK);
            }
        }

        private void clearFields()
        {
            instantiateDataDictionary(preDiveTable, operationTable);
            instantiateDataDictionary(debriefTable, operationTable);
        }

        private void storeDiver(TextBox text)
        {
            diverTable.data["name"] = text.Text;
        }

        private void storeData(TextBox text)
        {
            operationTable.data[text.Name] = text.Text;
        }

        private void storeData(MaskedTextBox text)
        {
            operationTable.data[text.Name] = text.Text;
        }

        private void storeData(ComboBox text)
        {
            operationTable.data[text.Name] = text.Text;
        }

        private void storeData(DateTimePicker text)
        {
            string date = text.Value.Date.ToString();
            date = date.Remove(date.Length - 12);
            operationTable.data[text.Name] = date;
        }

        private void storeData(CheckBox text)
        {
            operationTable.data[text.Name] = text.CheckState.ToString();
        }

        private void switchToPanel(Panel pnl)
        {
            startPanel.Visible = false;
            diverLogPanel.Visible = false;
            reportPanel.Visible = false;
            preDivePanel.Visible = false;
            activeDivePanel.Visible = false;
            postDivePanel.Visible = false;
            pnl.Visible = true;
        }

        private void setActiveButtonColor(Button btn)
        {
            startButton.BackColor = Color.DimGray;
            diverLogButton.BackColor = Color.DimGray;
            reportButton.BackColor = Color.DimGray;
            preDiveButton.BackColor = Color.DimGray;
            activeDiveButton.BackColor = Color.DimGray;
            postDiveButton.BackColor = Color.DimGray;
            btn.BackColor = Color.DarkCyan;
        }

        private void populateFields(DBTable tableName)
        {
            populateFields(debriefTable, tableName);
            populateFields(preDiveTable, tableName);
        }

        private void populateFields(TableLayoutPanel page, DBTable tableName)
        {
            foreach (Control c in page.Controls)
            {
                if (c is TextBox)
                {
                    if (tableName.data.ContainsKey(c.Name))
                    {
                        c.Text = tableName.data[c.Name];
                    }
                }
                if (c is MaskedTextBox)
                {
                    if (tableName.data.ContainsKey(c.Name))
                    {
                        c.Text = tableName.data[c.Name];
                    }
                }
                if (c is ComboBox)
                {
                    if (tableName.data.ContainsKey(c.Name))
                    {
                        c.Text = tableName.data[c.Name];
                    }
                }
                if (c is DateTimePicker)
                {
                    if (tableName.data.ContainsKey(c.Name))
                    {
                        c.Text = tableName.data[c.Name];
                    }
                }
                if (c is CheckBox)
                {
                    if (tableName.data.ContainsKey(c.Name))
                    {
                        CheckBox option = (CheckBox)c;
                        if (tableName.data[c.Name] == "Checked")
                        {
                            option.Checked = true;
                        }
                        else
                        {
                            option.Checked = false;
                        }
                    }
                }
            }
        }

        private void instantiateDataDictionary(TableLayoutPanel page, DBTable tableName)
        {
            foreach (Control c in page.Controls)
            {
                if (!(c is Label) && !(c is CheckBox))
                {
                    
                    tableName.data[c.Name] = "";
                }
                else if (c is CheckBox)
                {
                    tableName.data[c.Name] = "Unchecked";
                }
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            switchToPanel(startPanel);
            setActiveButtonColor(startButton);

        }

        private void diverLogButton_Click(object sender, EventArgs e)
        {
            switchToPanel(diverLogPanel);
            setActiveButtonColor(diverLogButton);
        }

        private void Start_Load(object sender, EventArgs e)
        {

        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            switchToPanel(reportPanel);
            setActiveButtonColor(reportButton);
        }

        private void preDiveButton_Click(object sender, EventArgs e)
        {
            switchToPanel(preDivePanel);
            setActiveButtonColor(preDiveButton);
        }

        private void activeDiveButton_Click(object sender, EventArgs e)
        {
            switchToPanel(activeDivePanel);
            setActiveButtonColor(activeDiveButton);
        }

        private void postDiveButton_Click(object sender, EventArgs e)
        {
            switchToPanel(postDivePanel);
            setActiveButtonColor(postDiveButton);
        }

        private void startPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void debriefDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            storeData((DateTimePicker)sender);
        }

        private void debriefVesselText_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            insertOperationData();
        }

        private void debriefEquipmentText_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void debriefPropertyText_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void debriefWorkedWellText_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void debriefNotWorkedWellText_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            List<string> reportNumbers = generateReportNumbers();
            string reportNum = Prompt.ShowDialog("Report number:", "Select a Report", reportNumbers);
            //Console.WriteLine(reportNum);
            if (reportNum != "Report number:")
            {
                populateOperationTableData(reportNum);
                populateFields(operationTable);
                showOperationButtons(true);
                switchToPanel(preDivePanel);
                setActiveButtonColor(preDiveButton);
            }
        }

        private void debriefInjuriesSupervisorCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            storeData((ComboBox)sender);
        }

        private void debriefPropertySupervisorCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            storeData((ComboBox)sender);
        }

        private void preStandardDiveGear_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preStandardTenderGear_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void prePatrolSupervisor_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preDispatch_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preShiftCommander_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preSrandardSwiftwaterGear_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preStandardIceRescueGear_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preOtherGear_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preAvistaGCC_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preUpriverDam_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preDeaconessHyperbaricChamber_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preOtherNotifications_CheckedChanged(object sender, EventArgs e)
        {
            storeData((CheckBox)sender);
        }

        private void preDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            storeData((DateTimePicker)sender);
        }

        private void preReportNum_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preStateMissionNum_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preOpPlanCompletedBy_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preCaseInvestigator_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preBriefingLocation_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preSituation_SelectedIndexChanged(object sender, EventArgs e)
        {
            storeData((ComboBox)sender);
        }

        private void preTypeOfOperation_SelectedIndexChanged(object sender, EventArgs e)
        {
            storeData((ComboBox)sender);
        }

        private void preAnticipatedDate_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            storeData((MaskedTextBox)sender);
        }

        private void preAnticipatedTime_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            storeData((MaskedTextBox)sender);
        }

        private void preLocationAndDescription_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preSiteSurvey_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWitnessName_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWitnessPhone_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            storeData((MaskedTextBox)sender);
        }

        private void preWitnessAddress_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehicleMake_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehicleModel_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehicleYear_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehicleColor_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehiclePlate_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preSceneAssessment_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterFlow_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterVisibility_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterObstructions_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterTemp_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterDepth_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preWaterHazards_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preLightning_SelectedIndexChanged(object sender, EventArgs e)
        {
            storeData((ComboBox)sender);
        }

        private void preAccess_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preOtherThreats_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preOperationObjectives_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void prePersonnelInvolved_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preVehiclesInvolved_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void prePrimaryRadioChannel_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preSecondaryRadioChannel_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void prePrimarySubsurfaceChannel_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void preSecondarySubsurfaceChannel_TextChanged(object sender, EventArgs e)
        {
            storeData((TextBox)sender);
        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            clearFields();
            populateFields(operationTable);
            showOperationButtons(true);
            switchToPanel(preDivePanel);
            setActiveButtonColor(preDiveButton);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            List<string> reportNumbers = generateReportNumbers();
            string reportNum = Prompt.ShowDialog("Report number:", "Select a Report", reportNumbers);
            //Console.WriteLine(reportNum);
            if (reportNum != "Report number:")
            {
                populateOperationTableData(reportNum);
                populateFields(operationTable);
                showOperationButtons(true);
                switchToPanel(preDivePanel);
                setActiveButtonColor(preDiveButton);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            clearFields();
            populateFields(operationTable);
            showOperationButtons(true);
            switchToPanel(preDivePanel);
            setActiveButtonColor(preDiveButton);
        }

        private void addDiver_Click(object sender, EventArgs e)
        {
            List<string> diverNames = generateDivers();
            if (diverNames.Contains(diverTable.data["name"]))
            {
                MessageBox.Show("A diver with that name already exists - Please enter a unique diver name", "Diver Name Already Taken", MessageBoxButtons.OK);
            }
            else
            {
                diverTable.setValues();
                diverTable.setInsertString();
                command = new SQLiteCommand(diverTable.insertString, connection);
                command.ExecuteNonQuery();
                MessageBox.Show(diverTable.data["name"] + " was succesfully added to the diver log", "Diver Name Already Taken", MessageBoxButtons.OK);
                generateDiverList();
            }
        }

        private void diverName_TextChanged(object sender, EventArgs e)
        {
            storeDiver((TextBox)sender);
        }

        private void removeDiver_Click(object sender, EventArgs e)
        {
            List<string> divers = generateDivers();
            string diver = Prompt.ShowDialog("Diver:", "Select a Diver", divers);
            if (diver != "Diver:")
            {
                string dropRow = "DELETE FROM Diver WHERE name ==" + "'" + diver + "'";
                command = new SQLiteCommand(dropRow, connection);
                command.ExecuteNonQuery();
                generateDiverList();
            }
        }

        private void incidentListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}