﻿using System;

public class db
{
	public db()
	{
	}
}
